# Tilvora: Sparrow and jagua-rs source code / Kaynak kodu

English first, Turkish below. / Önce İngilizce, aşağıda Türkçe.

## English

Tilvora, a nesting program by Yasin Beygirci (OstlerTech), uses a build of
Sparrow as its irregular-shape nesting engine. This archive is the complete
corresponding source of that build.

| Component | Licence | Version | Source |
|---|---|---|---|
| Sparrow (fork used by Tilvora) | MIT (see `LICENSE-MIT-sparrow`) | based on upstream commit `ca4ee65`, Tilvora fork commit `b44b411` | this archive (everything except `third_party/`) |
| jagua-rs | MPL-2.0 (see `LICENSE-MPL-2.0-jagua-rs`) | 2.0.0, upstream git tag `v2.0.0`, commit `783a1f27171c3ee64c0ac7282d961ff210bb97ee` | `third_party/jagua-rs-2.0.0/` and https://github.com/JeroenGar/jagua-rs |

jagua-rs has NOT been modified. `third_party/jagua-rs-2.0.0/` is the unmodified
crates.io package; its `src/` directory is byte-identical to `jagua-rs/src/` in
the upstream `v2.0.0` tag. Sparrow is modified: the Tilvora additions are new
files (`src/sheet/`, `src/optimizer/problem.rs`) and small changes to existing
Sparrow files; all of them are included here under the MIT licence.

Other dependencies are pinned in `Cargo.lock` and come from crates.io under their
own licences (mostly MIT or Apache-2.0).

How to build (Rust 1.90 or newer; the Windows build uses a static C runtime,
see `.cargo/config.toml`):

    cargo build --release --locked

The result is `target/release/sparrow` (`sparrow.exe` on Windows). The JSON
interface used by Tilvora is described in `ARAYUZ.md` (Turkish).

The programs are provided "as is", without warranty, under the licences above.
Questions: destek@ostlertech.com

## Türkçe

Tilvora (Yasin Beygirci, OstlerTech), düzensiz şekilli parça yerleşimi için
Sparrow'un bir derlemesini kullanır. Bu arşiv, o derlemenin tam kaynak kodudur.

- Sparrow (Tilvora'nın kullandığı çatal): MIT lisansı, üst kaynak commit `ca4ee65`, Tilvora çatalı commit `b44b411`. Kaynağı bu arşivdedir.
- jagua-rs: MPL-2.0 lisansı, sürüm 2.0.0 (`v2.0.0` etiketi, commit `783a1f27171c3ee64c0ac7282d961ff210bb97ee`). **jagua-rs'e hiçbir değişiklik yapılmadı.** `third_party/jagua-rs-2.0.0/` crates.io paketinin değiştirilmemiş kopyasıdır; `src/` klasörü üst kaynağın `v2.0.0` etiketiyle bayt bayt aynıdır.
- Diğer bağımlılıklar `Cargo.lock` ile sabitlenmiştir ve crates.io'dan kendi lisanslarıyla gelir.

Derleme: `cargo build --release --locked` (Rust 1.90 ve üstü).
Soru için: destek@ostlertech.com
