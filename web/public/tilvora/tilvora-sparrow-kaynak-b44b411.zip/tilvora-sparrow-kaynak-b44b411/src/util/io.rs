use crate::sheet::io::ExtSheetInstance;
use anyhow::{Context, Result};
use jagua_rs::probs::spp::io::ext_repr::{ExtSPInstance, ExtSPSolution};
use log::{log, Level};
use serde::{Deserialize, Serialize};
use std::fs;
use std::fs::File;
use std::io::BufReader;
use std::path::Path;
use svg::Document;

#[derive(Serialize, Deserialize, Clone)]
pub struct ExtSPOutput {
    #[serde(flatten)]
    pub instance: ExtSPInstance,
    pub solution: ExtSPSolution,
}

pub fn write_svg(document: &Document, path: &Path, log_lvl: Level) -> Result<()> {
    //make sure the parent directory exists
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).context("could not create parent directory for svg file")?;
    }
    svg::save(path, document)?;
    log!(log_lvl,
        "[IO] svg exported to file://{}",
        fs::canonicalize(path)
            .expect("could not canonicalize path")
            .to_str()
            .unwrap()
    );
    Ok(())
}

pub fn write_json(json: &impl Serialize, path: &Path, log_lvl: Level) -> Result<()> {
    let file = File::create(path)?;
    serde_json::to_writer_pretty(file, json)?;
    log!(log_lvl,
        "[IO] json exported to file://{}",
        fs::canonicalize(path)
            .expect("could not canonicalize path")
            .to_str()
            .unwrap()
    );
    Ok(())
}

pub fn read_spp_input(path: &Path) -> Result<(ExtSPInstance, Option<ExtSPSolution>)> {
    let input_str = fs::read_to_string(path).context("could not read input file")?;
    parse_spp_input(&input_str)
}

fn parse_spp_input(input_str: &str) -> Result<(ExtSPInstance, Option<ExtSPSolution>)> {
    //try parsing a full output (instance + solution)
    match serde_json::from_str::<ExtSPOutput>(input_str) {
        Ok(ext_output) => {
            Ok((ext_output.instance, Some(ext_output.solution)))
        }
        Err(_) => {
            //try parsing just the instance
            let ext_instance = serde_json::from_str::<ExtSPInstance>(input_str)
                .context("could not parse instance from input file")?;
            Ok((ext_instance, None))
        }
    }
}

/// Either a strip packing input (optionally with a solution to warm start from) or a multi-sheet instance.
pub enum InputKind {
    Strip(ExtSPInstance, Option<ExtSPSolution>),
    Sheet(ExtSheetInstance),
}

/// Reads an input file: a `sheet` object selects the multi-sheet mode, otherwise the file is parsed as strip packing input.
pub fn read_input(path: &Path) -> Result<InputKind> {
    let input_str = fs::read_to_string(path).context("could not read input file")?;
    let value: serde_json::Value = serde_json::from_str(&input_str).context("input file is not valid JSON")?;
    match value.get("sheet") {
        Some(_) => {
            let ext_instance = serde_json::from_value::<ExtSheetInstance>(value)
                .context("could not parse multi-sheet instance from input file")?;
            Ok(InputKind::Sheet(ext_instance))
        }
        None => {
            let (instance, solution) = parse_spp_input(&input_str)?;
            Ok(InputKind::Strip(instance, solution))
        }
    }
}
