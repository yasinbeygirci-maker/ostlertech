//! Fixed-size multi-sheet packing ("bin packing with identical bins") on top of Sparrow's strip
//! machinery (Tilvora addition, MIT; no `jagua-rs` file is modified).
//!
//! # Model
//! All sheets are laid side by side along the x-axis inside ONE container. Sheet `j` occupies
//! `[j * pitch, j * pitch + width]` where `pitch = width + gap`. Between consecutive sheets a static
//! hole ("bar") blocks the region from the usable right edge of sheet `j` to the usable left edge of
//! sheet `j + 1`, so no item can straddle two sheets. The sheet edge margin is modelled by the same
//! bars and by the container outline. The container's right edge is the "strip width" `X` Sparrow
//! shrinks: minimizing `X` minimizes first the number of sheets and then the used width of the last
//! sheet, which leaves the unused remainder of the last sheet as one rectangular piece.
//!
//! # Separation (kerf) and margin
//! `jagua-rs` realises `min_item_separation` by inflating items and holes by `sep / 2` and
//! deflating the container outline by `sep / 2`. To keep the full `sep` between items but NOT
//! consume kerf at sheet edges, the container outline is handed over `sep` larger than the usable
//! region and the bars `sep` narrower. After `jagua-rs`'s modification the collision outline is
//! `sep / 2` larger and the collision bars `sep / 2` narrower than the usable regions, which exactly
//! compensates the `sep / 2` inflation of the items: original item shapes stay inside the usable
//! regions and keep `sep` between each other.
//!
//! All coordinates are "sheet coordinates": sheet 0 starts at `x = 0`, `y = 0` is the bottom edge.

use crate::optimizer::problem::{StripLike, StripSolution};
use anyhow::{Result, bail, ensure};
use jagua_rs::Instant;
use jagua_rs::collision_detection::CDEConfig;
use jagua_rs::entities::{Container, InferiorQualityZone, Item, Layout, LayoutSnapshot, PItemKey};
use jagua_rs::geometry::fail_fast::SPSurrogateConfig;
use jagua_rs::geometry::geo_enums::RotationRange;
use jagua_rs::geometry::geo_traits::Transformable;
use jagua_rs::geometry::primitives::{Rect, SPolygon};
use jagua_rs::geometry::shape_modification::{ShapeModifyConfig, ShapeModifyMode};
use jagua_rs::geometry::{DTransformation, OriginalShape, Transformation};
use jagua_rs::probs::spp::entities::SPPlacement;
use rand::{Rng, RngExt};
use std::sync::Arc;

pub mod compress;
pub mod greedy;
pub mod io;

/// Which items follow the moving right edge when the strip width changes during the search.
///
/// Sparrow's strip packing shifts everything right of the strip center. In multi-sheet mode this
/// pushes the items of every sheet in the right half across their left bar, so the separator spends
/// most of its effort restoring sheets that were already fine; only the last sheet should move.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum SplitMode {
    /// Sparrow's behaviour: split at the strip center (kept for comparison).
    Center,
    /// All items of the last sheet move (they collide with the bar left of the last sheet).
    TailStart,
    /// Items in the right half of the last sheet move (Sparrow's center split, at sheet scale).
    #[default]
    TailCenter,
    /// Nothing moves; the shrunk right edge cuts into the last sheet's rightmost items.
    End,
}

impl std::str::FromStr for SplitMode {
    type Err = String;

    fn from_str(s: &str) -> std::result::Result<Self, Self::Err> {
        match s {
            "center" => Ok(Self::Center),
            "tail-start" => Ok(Self::TailStart),
            "tail-center" => Ok(Self::TailCenter),
            "end" => Ok(Self::End),
            other => Err(format!("unknown split mode '{other}' (center | tail-start | tail-center | end)")),
        }
    }
}

/// Minimum width of a bar between two sheets, relative to the sheet width. Only used to keep the
/// bar a valid polygon when `gap + 2 * margin <= 2 * separation`; the gap lies outside the sheets
/// so it never reduces usable sheet area.
pub const MIN_BAR_WIDTH_RATIO: f32 = 1e-3;

/// Relative tolerance used when a width ends exactly on a sheet boundary.
const BOUNDARY_TOL: f32 = 1e-6;

/// Description of the (identical) sheets.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SheetSpec {
    /// Width of a sheet along the strip direction. `None` = a single unbounded sheet (plain strip).
    pub width: Option<f32>,
    /// Height of a sheet (the fixed strip height).
    pub height: f32,
    /// Edge margin inside each sheet; items keep at least this distance from every sheet edge.
    pub margin: f32,
    /// Dead space between consecutive sheets (outside the sheets). Raised automatically if needed.
    pub gap: f32,
    /// Maximum number of sheets available (`None` = unlimited). Only checked after optimization.
    pub max_count: Option<usize>,
}

impl SheetSpec {
    pub fn validate(&self, separation: f32) -> Result<()> {
        ensure!(
            separation.is_finite() && separation >= 0.0,
            "min_item_separation must be finite and nonnegative"
        );
        ensure!(self.height.is_finite() && self.height > 0.0, "sheet height must be positive");
        ensure!(self.margin.is_finite() && self.margin >= 0.0, "sheet margin must be finite and nonnegative");
        ensure!(self.gap.is_finite() && self.gap >= 0.0, "sheet gap must be finite and nonnegative");
        ensure!(self.usable_height() > 0.0, "margin leaves no usable sheet height");
        if let Some(w) = self.width {
            ensure!(w.is_finite() && w > 0.0, "sheet width must be positive");
            ensure!(w - 2.0 * self.margin > 0.0, "margin leaves no usable sheet width");
        }
        if let Some(n) = self.max_count {
            ensure!(n > 0, "sheet count must be positive");
        }
        Ok(())
    }

    /// Returns a copy whose gap is large enough for the bars to stay valid polygons after the
    /// separation offset. Pure function of the inputs; documented in ARAYUZ.md.
    #[must_use]
    pub fn with_effective_gap(mut self, separation: f32) -> Self {
        if let Some(w) = self.width {
            let min_gap = 2.0 * separation - 2.0 * self.margin + MIN_BAR_WIDTH_RATIO * w;
            self.gap = self.gap.max(min_gap);
        }
        self
    }

    /// Distance between the left edges of consecutive sheets.
    #[must_use]
    pub fn pitch(&self) -> Option<f32> {
        self.width.map(|w| w + self.gap)
    }

    #[must_use]
    pub fn usable_width(&self) -> Option<f32> {
        self.width.map(|w| w - 2.0 * self.margin)
    }

    #[must_use]
    pub fn usable_height(&self) -> f32 {
        self.height - 2.0 * self.margin
    }

    /// Left edge of the usable region of sheet `j` (sheet coordinates).
    #[must_use]
    pub fn usable_x_min(&self, j: usize) -> f32 {
        j as f32 * self.pitch().unwrap_or(0.0) + self.margin
    }

    /// Right edge of the usable region of sheet `j` (sheet coordinates); `None` for an unbounded sheet.
    #[must_use]
    pub fn usable_x_max(&self, j: usize) -> Option<f32> {
        self.width
            .map(|w| j as f32 * self.pitch().unwrap() + w - self.margin)
    }

    /// Index of the sheet containing sheet-coordinate `x` (clamped to 0 for negative x).
    #[must_use]
    pub fn sheet_index_of(&self, x: f32) -> usize {
        match self.pitch() {
            None => 0,
            Some(p) => (x / p).floor().max(0.0) as usize,
        }
    }
}

/// How a strip width `X` (usable right edge) maps onto sheets.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SheetGeometry {
    /// Number of sheets with a positive usable tail.
    pub n_sheets: usize,
    /// Usable width of the last sheet, in `(0, usable_width]`.
    pub tail_usable_width: f32,
    /// Right edge actually handed to the container (clamped inside the last sheet).
    pub effective_width: f32,
}

/// Resolves a strip width into a sheet count and a tail width.
///
/// `width` is the usable right edge. If it ends inside a bar (dead zone), it is clamped to the
/// usable right edge of the last sheet it still touches.
#[must_use]
pub fn resolve_width(spec: &SheetSpec, width: f32) -> SheetGeometry {
    let m = spec.margin;
    let Some(pitch) = spec.pitch() else {
        return SheetGeometry {
            n_sheets: 1,
            tail_usable_width: (width - m).max(0.0),
            effective_width: width.max(m),
        };
    };
    let usable = spec.usable_width().unwrap();
    let tol = BOUNDARY_TOL * pitch;
    let rel = ((width - m) / pitch).max(0.0);
    let mut n_sheets = rel.floor() as usize + 1;
    let mut tail = width - ((n_sheets - 1) as f32 * pitch + m);
    if tail <= tol && n_sheets > 1 {
        // The width ends at (or just after) the left usable edge of a sheet: that sheet is unused.
        n_sheets -= 1;
        tail = usable;
    }
    let tail = tail.clamp(tol.min(usable), usable);
    SheetGeometry {
        n_sheets,
        tail_usable_width: tail,
        effective_width: (n_sheets - 1) as f32 * pitch + m + tail,
    }
}

/// Snapshot of a [`SheetProblem`].
#[derive(Clone, Debug)]
pub struct SheetSolution {
    pub(crate) layout_snapshot: LayoutSnapshot,
    pub(crate) width: f32,
    pub(crate) spec: SheetSpec,
    pub(crate) separation: f32,
    pub time_stamp: Instant,
}

impl SheetSolution {
    #[must_use]
    pub fn geometry(&self) -> SheetGeometry {
        resolve_width(&self.spec, self.width)
    }

    #[must_use]
    pub fn spec(&self) -> &SheetSpec {
        &self.spec
    }

    /// Smallest usable right edge containing every placed item (see [`SheetProblem::fitted_width`]).
    #[must_use]
    pub fn fitted_width(&self) -> Option<f32> {
        self.layout_snapshot
            .placed_items()
            .values()
            .map(|pi| pi.shape().bbox().x_max)
            .max_by(f32::total_cmp)
            .map(|x| x * 1.00001 - self.separation / 2.0)
    }

    /// Left usable edge of the last sheet and the width its items actually use (`0` if empty).
    #[must_use]
    pub fn tail_usage(&self) -> (f32, f32) {
        let start = self.spec.usable_x_min(self.geometry().n_sheets - 1).min(self.width);
        let used = self.fitted_width().map_or(0.0, |f| (f - start).max(0.0));
        (start, used)
    }
}

impl StripSolution for SheetSolution {
    fn strip_width(&self) -> f32 {
        self.width
    }

    fn density(&self) -> f32 {
        self.layout_snapshot.density()
    }

    fn layout_snapshot(&self) -> &LayoutSnapshot {
        &self.layout_snapshot
    }
}

/// External IDs of the items that cannot lie inside one sheet's usable region in any allowed
/// rotation (bounding box test on the collision shapes, which are inflated by `sep / 2`).
/// Continuous rotation is not enumerated: such items are assumed placeable.
#[must_use]
pub fn unplaceable_items(items: &[(Arc<Item>, usize)], spec: &SheetSpec, separation: f32) -> Vec<u64> {
    let tol = 1e-4 * spec.width.unwrap_or(spec.height).max(spec.height);
    let max_w = spec.usable_width().map(|w| w + separation + tol);
    let max_h = spec.usable_height() + separation + tol;
    items
        .iter()
        .filter(|(item, _)| {
            let rotations: Vec<f32> = match item.allowed_orientations().rotations() {
                RotationRange::None => vec![0.0],
                RotationRange::Discrete(r) => r.clone(),
                RotationRange::Continuous => return false,
            };
            !rotations.iter().any(|&r| {
                let bbox = item
                    .shape_cd()
                    .transform_clone(&Transformation::from_rotation(r))
                    .bbox();
                bbox.height() <= max_h && max_w.is_none_or(|mw| bbox.width() <= mw)
            })
        })
        .map(|(item, _)| item.external_id())
        .collect()
}

/// Lazily built blocking bars, shared between containers of different widths.
///
/// Generating a bar's collision geometry costs tens of milliseconds (pole of inaccessibility of a
/// very thin rectangle), so bars are built once for a growing count and reused through
/// [`InferiorQualityZone::filtered`], which shares the already converted shapes.
#[derive(Clone, Debug, Default)]
pub struct BarCache {
    n_bars: usize,
    zone: Option<InferiorQualityZone>,
}

impl BarCache {
    /// Zone containing the first `n_bars` bars (bar `j` separates sheet `j - 1` from sheet `j`).
    fn zone_with(&mut self, spec: &SheetSpec, separation: f32, n_bars: usize) -> Result<Option<&InferiorQualityZone>> {
        if n_bars == 0 {
            return Ok(None);
        }
        if self.zone.is_none() || n_bars > self.n_bars {
            let n = n_bars.max(2 * self.n_bars);
            let (m, h, sep) = (spec.margin, spec.height, separation);
            let bars = (1..=n)
                .map(|j| {
                    let x_min = spec.usable_x_max(j - 1).unwrap() + sep;
                    let x_max = spec.usable_x_min(j) - sep;
                    let rect = Rect::try_new(x_min, m - sep, x_max, h - m + sep)?;
                    Ok(OriginalShape {
                        shape: SPolygon::try_from(rect)?,
                        pre_transform: DTransformation::empty(),
                        modify_mode: ShapeModifyMode::Inflate,
                        modify_config: modify_config(sep),
                    })
                })
                .collect::<Result<Vec<_>>>()?;
            // Bars are only collision targets: the pole of inaccessibility (always present) suffices,
            // no fail-fast poles are needed and they would be very slow to generate for thin shapes.
            self.zone = Some(InferiorQualityZone::new(0, bars, SPSurrogateConfig::none())?);
            self.n_bars = n;
        }
        Ok(self.zone.as_ref())
    }
}

/// Items packed into identical fixed-size sheets, laid out as one strip with blocking bars.
#[derive(Clone)]
pub struct SheetProblem {
    items: Vec<(Arc<Item>, usize)>,
    spec: SheetSpec,
    separation: f32,
    cde_config: CDEConfig,
    bars: BarCache,
    layout: Layout,
    width: f32,
    item_demand_qtys: Vec<usize>,
    split_mode: SplitMode,
    /// Exploration shrink step as a fraction of the sheet pitch; `None` = Sparrow's relative step.
    step_ratio: Option<f32>,
}

impl SheetProblem {
    /// Creates a problem with an initial width corresponding to 100% density of an unbounded strip.
    ///
    /// * `items` must be indexed by `item.idx()` and carry their demand.
    /// * `separation` is the minimum distance between items (kerf); the items must have been imported
    ///   with the same separation (see [`io::import_instance`]).
    pub fn new(
        items: Vec<(Arc<Item>, usize)>,
        spec: SheetSpec,
        separation: f32,
        cde_config: CDEConfig,
    ) -> Result<Self> {
        ensure!(!items.is_empty(), "instance must have positive item demand");
        ensure!(
            items.iter().enumerate().all(|(i, (item, _))| item.idx() == i),
            "item indices must match their positions"
        );
        spec.validate(separation)?;
        let spec = spec.with_effective_gap(separation);
        let unplaceable = unplaceable_items(&items, &spec, separation);
        ensure!(
            unplaceable.is_empty(),
            "items do not fit in a sheet in any allowed rotation (external ids): {unplaceable:?}"
        );
        let item_demand_qtys = items.iter().map(|(_, qty)| *qty).collect();
        let total_area: f32 = items
            .iter()
            .map(|(item, qty)| item.area() * *qty as f32)
            .sum();
        let initial_width = spec.margin + total_area / spec.usable_height();

        let mut bars = BarCache::default();
        let container = build_container(&spec, separation, cde_config, initial_width, &mut bars)?;
        Ok(Self {
            items,
            spec,
            separation,
            cde_config,
            bars,
            layout: Layout::new(container),
            width: initial_width,
            item_demand_qtys,
            split_mode: SplitMode::default(),
            step_ratio: None,
        })
    }

    /// Selects which items follow the moving edge during the search (default [`SplitMode::TailCenter`]).
    #[must_use]
    pub fn with_split_mode(mut self, mode: SplitMode) -> Self {
        self.split_mode = mode;
        self
    }

    /// Exploration shrink step as a fraction of the sheet pitch (`None` = Sparrow's relative step).
    /// Only meaningful for bounded sheets.
    #[must_use]
    pub fn with_step_ratio(mut self, ratio: Option<f32>) -> Self {
        self.step_ratio = ratio.filter(|r| r.is_finite() && *r > 0.0);
        self
    }

    #[must_use]
    pub fn split_mode(&self) -> SplitMode {
        self.split_mode
    }

    #[must_use]
    pub fn spec(&self) -> &SheetSpec {
        &self.spec
    }

    /// `[left usable edge of the last sheet, strip width]` in sheet coordinates.
    #[must_use]
    pub fn tail_range(&self) -> (f32, f32) {
        let geom = self.geometry();
        let start = self.spec.usable_x_min(geom.n_sheets - 1).min(self.width);
        (start, self.width)
    }

    /// Smallest usable right edge that still contains every placed item (`None` if nothing is placed).
    /// Collision shapes are inflated by sep/2; the usable right edge is sep/2 left of their x_max.
    #[must_use]
    pub fn fitted_width(&self) -> Option<f32> {
        self.layout
            .placed_items()
            .values()
            .map(|pi| pi.shape().bbox().x_max)
            .max_by(f32::total_cmp)
            .map(|x| x * 1.00001 - self.separation / 2.0)
    }

    /// Strip width at which exactly `n_sheets` full sheets are usable.
    #[must_use]
    pub fn width_for_sheets(&self, n_sheets: usize) -> f32 {
        match self.spec.usable_x_max(n_sheets.max(1) - 1) {
            Some(w) => w,
            None => self.width,
        }
    }

    #[must_use]
    pub fn separation(&self) -> f32 {
        self.separation
    }

    #[must_use]
    pub fn geometry(&self) -> SheetGeometry {
        resolve_width(&self.spec, self.width)
    }

    fn register_included_item(&mut self, item_idx: usize) {
        assert!(self.item_demand_qtys[item_idx] > 0, "item demand exhausted");
        self.item_demand_qtys[item_idx] -= 1;
    }

    fn deregister_included_item(&mut self, item_idx: usize) {
        self.item_demand_qtys[item_idx] += 1;
    }
}

/// Offset handed to `jagua-rs` for the container and bars: half the separation, or none.
fn modify_config(separation: f32) -> ShapeModifyConfig {
    ShapeModifyConfig {
        offset: (separation > 0.0).then_some(separation / 2.0),
        simplify_tolerance: None,
        narrow_concavity_cutoff: None,
    }
}

/// Builds the container for a given width: outline plus one blocking bar between consecutive sheets.
/// Bars (`sep` narrower than the dead zone, inflated by `sep / 2` by jagua-rs) come from `bars`.
pub fn build_container(
    spec: &SheetSpec,
    separation: f32,
    cde_config: CDEConfig,
    width: f32,
    bars: &mut BarCache,
) -> Result<Container> {
    let geom = resolve_width(spec, width);
    let (m, h, sep) = (spec.margin, spec.height, separation);
    ensure!(
        geom.effective_width > m,
        "width {width} leaves no usable region"
    );

    // Outline: `sep` larger than the usable region, jagua-rs deflates it by `sep / 2`.
    let outer = Rect::try_new(m - sep, m - sep, geom.effective_width + sep, h - m + sep)?;
    let outline = OriginalShape {
        shape: SPolygon::try_from(outer)?,
        pre_transform: DTransformation::empty(),
        modify_mode: ShapeModifyMode::Deflate,
        modify_config: modify_config(sep),
    };

    let zones = match bars.zone_with(spec, sep, geom.n_sheets - 1)? {
        // keep only the bars left of the outline's right edge
        Some(zone) => vec![zone.filtered(|s| s.bbox().x_min < geom.effective_width)],
        None => vec![],
    };

    Container::new(outline, zones, cde_config)
}

impl StripLike for SheetProblem {
    type Solution = SheetSolution;

    fn layout(&self) -> &Layout {
        &self.layout
    }

    fn strip_width(&self) -> f32 {
        self.width
    }

    fn change_strip_width(&mut self, new_width: f32) -> Result<()> {
        ensure!(new_width.is_finite(), "strip width must be finite");
        if new_width <= self.spec.margin {
            bail!("strip width {new_width} leaves no usable region");
        }
        let container = build_container(&self.spec, self.separation, self.cde_config, new_width, &mut self.bars)?;
        self.layout.swap_container(container);
        self.width = new_width;
        Ok(())
    }

    fn fit_strip(&mut self) -> Result<()> {
        let fitted = self.fitted_width().ok_or_else(|| anyhow::anyhow!("cannot fit an empty strip"))?;
        self.change_strip_width(fitted.max(self.spec.margin * 1.00001 + f32::EPSILON))
    }

    fn place_item(&mut self, placement: SPPlacement) -> PItemKey {
        self.register_included_item(placement.item_idx);
        let item = &self.items[placement.item_idx].0;
        self.layout.place_item(item, placement.d_transf)
    }

    fn remove_item(&mut self, pk: PItemKey) -> SPPlacement {
        let pi = self.layout.remove_item(pk);
        self.deregister_included_item(pi.item().idx());
        SPPlacement {
            item_idx: pi.item().idx(),
            d_transf: pi.d_transf(),
        }
    }

    fn save(&self) -> SheetSolution {
        SheetSolution {
            layout_snapshot: self.layout.save(),
            width: self.width,
            spec: self.spec,
            separation: self.separation,
            time_stamp: Instant::now(),
        }
    }

    fn restore(&mut self, solution: &SheetSolution) {
        // A saved solution may use a different width (and thus a different container).
        if self.layout.restore(&solution.layout_snapshot).is_err() {
            self.layout = Layout::from_snapshot(&solution.layout_snapshot);
        }
        self.width = solution.width;
        for (idx, qty) in self.item_demand_qtys.iter_mut().enumerate() {
            *qty = self.items[idx].1;
        }
        for pi in self.layout.placed_items().values() {
            self.item_demand_qtys[pi.item().idx()] -= 1;
        }
    }

    fn density(&self) -> f32 {
        self.layout.density()
    }

    fn items(&self) -> &[(Arc<Item>, usize)] {
        &self.items
    }

    fn item_demand_qtys(&self) -> &[usize] {
        &self.item_demand_qtys
    }

    fn next_explore_width(&self, current_width: f32, shrink_step: f32) -> f32 {
        let step = match (self.step_ratio, self.spec.pitch()) {
            (Some(ratio), Some(pitch)) => ratio * pitch,
            _ => current_width * shrink_step,
        };
        // With a tail-only split the items never spread to the right edge by themselves: start
        // the step from the width the items actually occupy, so an empty tail is not shrunk
        // 0.1% at a time. The center split keeps Sparrow's behaviour.
        let from = match (self.split_mode, self.spec.width) {
            (SplitMode::Center, _) | (_, None) => current_width,
            _ => self.fitted_width().map_or(current_width, |w| w.min(current_width)),
        };
        from - step
    }

    fn explore_split_position(&self) -> f32 {
        if self.spec.width.is_none() {
            return self.width / 2.0;
        }
        let (start, end) = self.tail_range();
        match self.split_mode {
            SplitMode::Center => self.width / 2.0,
            SplitMode::TailStart => start,
            SplitMode::TailCenter => 0.5 * (start + end),
            SplitMode::End => end,
        }
    }

    fn compress_split_position(&self, rng: &mut impl Rng) -> f32 {
        if self.spec.width.is_none() || self.split_mode == SplitMode::Center {
            return rng.random_range(0.0..self.width);
        }
        let (start, end) = self.tail_range();
        if end > start {
            rng.random_range(start..end)
        } else {
            end
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn spec() -> SheetSpec {
        SheetSpec {
            width: Some(6000.0),
            height: 3210.0,
            margin: 10.0,
            gap: 0.0,
            max_count: None,
        }
    }

    #[test]
    fn width_inside_first_sheet() {
        let g = resolve_width(&spec(), 4000.0);
        assert_eq!(g.n_sheets, 1);
        assert!((g.tail_usable_width - 3990.0).abs() < 1e-3);
        assert!((g.effective_width - 4000.0).abs() < 1e-3);
    }

    #[test]
    fn width_in_dead_zone_is_clamped_to_previous_sheet() {
        // 5995 lies in the bar [5990, 6010]: sheet 0 full, nothing of sheet 1 used.
        let g = resolve_width(&spec(), 5995.0);
        assert_eq!(g.n_sheets, 1);
        assert!((g.tail_usable_width - 5980.0).abs() < 1e-3);
        assert!((g.effective_width - 5990.0).abs() < 1e-3);
        let g = resolve_width(&spec(), 6010.0);
        assert_eq!(g.n_sheets, 1, "exactly on the usable left edge of sheet 1 means sheet 1 unused");
    }

    #[test]
    fn width_into_third_sheet() {
        let g = resolve_width(&spec(), 2.0 * 6000.0 + 10.0 + 123.0);
        assert_eq!(g.n_sheets, 3);
        assert!((g.tail_usable_width - 123.0).abs() < 1e-3);
    }

    #[test]
    fn unbounded_sheet_is_a_strip() {
        let s = SheetSpec { width: None, ..spec() };
        let g = resolve_width(&s, 123456.0);
        assert_eq!(g.n_sheets, 1);
        assert!((g.effective_width - 123456.0).abs() < 1e-3);
    }

    #[test]
    fn split_positions_stay_inside_the_last_sheet() {
        use jagua_rs::io::ext_repr::{ExtItem, ExtOrientation, ExtRotation, ExtShape, ExtSPolygon};
        use jagua_rs::io::import::Importer;
        use rand::SeedableRng;

        let cfg = crate::config::DEFAULT_SPARROW_CONFIG;
        let importer = Importer::new(cfg.cde_config, cfg.poly_simpl_tolerance, cfg.narrow_concavity_cutoff_ratio);
        let item = importer.import_item(&ExtItem {
            id: 1,
            orientation: ExtOrientation { rotation: ExtRotation::Discrete { angles: vec![0.0] }, reflection_axes: vec![] },
            shape: ExtShape::SimplePolygon(ExtSPolygon(vec![(0.0, 0.0), (1000.0, 0.0), (1000.0, 1000.0), (0.0, 1000.0)])),
            min_quality: None,
        }, 0).unwrap();
        let mut prob = SheetProblem::new(vec![(item, 60)], spec(), 0.0, cfg.cde_config).unwrap();
        // 2 full sheets + 1500 mm of a third
        let w = 2.0 * 6000.0 + 10.0 + 1500.0;
        prob.change_strip_width(w).unwrap();
        assert_eq!(prob.geometry().n_sheets, 3);
        let (start, end) = prob.tail_range();
        assert!((start - (2.0 * 6000.0 + 10.0)).abs() < 1e-3);
        assert!((end - w).abs() < 1e-3);

        let mut rng = rand::rngs::Xoshiro256PlusPlus::seed_from_u64(1);
        let p = prob.clone().with_split_mode(SplitMode::TailCenter);
        assert!((p.explore_split_position() - (start + 750.0)).abs() < 1e-2);
        for _ in 0..100 {
            let s = p.compress_split_position(&mut rng);
            assert!(s >= start && s < end, "{s}");
        }
        assert!((prob.clone().with_split_mode(SplitMode::TailStart).explore_split_position() - start).abs() < 1e-3);
        assert!((prob.clone().with_split_mode(SplitMode::End).explore_split_position() - end).abs() < 1e-3);
        let c = prob.clone().with_split_mode(SplitMode::Center);
        assert!((c.explore_split_position() - w / 2.0).abs() < 1e-3);
        assert!((0..100).map(|_| c.compress_split_position(&mut rng)).any(|s| s < start), "center mode samples the whole strip");

        // step: relative by default, a fraction of the pitch when configured
        assert!((prob.next_explore_width(w, 0.001) - w * 0.999).abs() < 1e-2);
        let s = prob.clone().with_step_ratio(Some(0.05));
        assert!((s.next_explore_width(w, 0.001) - (w - 300.0)).abs() < 1e-2);
        assert!((prob.width_for_sheets(2) - (6000.0 + 6000.0 - 10.0)).abs() < 1e-3);
    }

    #[test]
    fn effective_gap_keeps_bar_positive() {
        let s = SheetSpec { margin: 0.0, ..spec() }.with_effective_gap(5.0);
        // bar handed to jagua-rs = gap + 2m - 2sep must be >= MIN_BAR_WIDTH_RATIO * w
        assert!(s.gap + 2.0 * s.margin - 2.0 * 5.0 >= MIN_BAR_WIDTH_RATIO * 6000.0 - 1e-3);
        let s2 = spec().with_effective_gap(0.0);
        assert_eq!(s2.gap, 0.0, "a 20 mm bar from margins needs no extra gap");
    }

    /// Timing probe (prints only): how long do container builds and an LBF placement search take
    /// with many bars? Run with `cargo test timing_probe -- --nocapture`.
    #[test]
    fn timing_probe() {
        use crate::eval::lbf_evaluator::LBFEvaluator;
        use crate::sample::search::search_placement;
        use jagua_rs::io::ext_repr::{ExtItem, ExtOrientation, ExtRotation, ExtShape, ExtSPolygon};
        use jagua_rs::io::import::Importer;
        use rand::SeedableRng;

        let cfg = crate::config::DEFAULT_SPARROW_CONFIG;
        let s = SheetSpec { width: Some(3000.0), height: 4900.0, margin: 20.0, gap: 0.0, max_count: None };
        let mut cache = BarCache::default();
        for n in [3usize, 10, 100, 100, 50] {
            let w = (n - 1) as f32 * 3000.0 + 20.0 + 1000.0;
            let t = std::time::Instant::now();
            let c = build_container(&s, 10.0, cfg.cde_config, w, &mut cache).unwrap();
            println!("build_container {n} sheets: {:?} (bars {})", t.elapsed(), c.quality_zones()[0].as_ref().map_or(0, |z| z.shapes_cd().len()));
            // LBF-like search for a 2000 x 2200 rectangle in the empty layout
            let importer = Importer::new(cfg.cde_config, cfg.poly_simpl_tolerance, cfg.narrow_concavity_cutoff_ratio)
                .with_min_item_separation(10.0).unwrap();
            let item = importer.import_item(&ExtItem {
                id: 1,
                orientation: ExtOrientation { rotation: ExtRotation::Discrete { angles: vec![0.0, 180.0] }, reflection_axes: vec![] },
                shape: ExtShape::SimplePolygon(ExtSPolygon(vec![(0.0, 0.0), (2000.0, 0.0), (2000.0, 2200.0), (0.0, 2200.0)])),
                min_quality: None,
            }, 0).unwrap();
            let layout = Layout::new(c);
            let mut rng = rand::rngs::Xoshiro256PlusPlus::seed_from_u64(1);
            let t = std::time::Instant::now();
            let (best, n_evals) = search_placement(&layout, &item, None, LBFEvaluator::new(&layout, &item), crate::consts::LBF_SAMPLE_CONFIG, &mut rng);
            println!("search_placement {n} sheets: {:?}, evals {n_evals}, found {}", t.elapsed(), best.is_some());
        }
    }

    #[test]
    fn container_has_one_bar_per_boundary() {
        let s = spec();
        let cde = crate::config::DEFAULT_SPARROW_CONFIG.cde_config;
        let mut cache = BarCache::default();
        let c = build_container(&s, 4.0, cde, 2.0 * 6000.0 + 10.0 + 500.0, &mut cache).unwrap();
        let bars = c.quality_zones()[0].as_ref().unwrap();
        assert_eq!(bars.shapes_cd().len(), 2);
        // a narrower width reuses the cached bars and keeps only those left of the outline
        let c1 = build_container(&s, 4.0, cde, 6000.0 + 10.0 + 500.0, &mut cache).unwrap();
        assert_eq!(c1.quality_zones()[0].as_ref().unwrap().shapes_cd().len(), 1);
        let c0 = build_container(&s, 4.0, cde, 3000.0, &mut cache).unwrap();
        assert!(c0.quality_zones()[0].is_none() || c0.quality_zones()[0].as_ref().unwrap().shapes_cd().is_empty());
        // Dead zone between sheet 0 and 1 is [5990, 6010]; with sep = 4 the collision bar is
        // sep/2 narrower on each side, compensating the sep/2 inflation of the items.
        let b = bars.shapes_cd()[0].bbox();
        assert!((b.x_min - 5992.0).abs() < 0.05, "{b:?}");
        assert!((b.x_max - 6008.0).abs() < 0.05, "{b:?}");
        // Collision outline is sep/2 larger than the usable region [10, 12510] x [10, 3200].
        let o = c.outer_cd().bbox();
        assert!((o.x_min - 8.0).abs() < 0.05, "{o:?}");
        assert!((o.x_max - (2.0 * 6000.0 + 10.0 + 500.0 + 2.0)).abs() < 0.05, "{o:?}");
        assert!((o.y_min - 8.0).abs() < 0.05, "{o:?}");
        assert!((o.y_max - 3202.0).abs() < 0.05, "{o:?}");
    }
}
