#[cfg(test)]
mod integration_tests {
    use anyhow::Result;
    use jagua_rs::io::import::Importer;
    use sparrow::config::DEFAULT_SPARROW_CONFIG;
    use sparrow::consts::LBF_SAMPLE_CONFIG;
    use sparrow::optimizer::compress::compression_phase;
    use sparrow::optimizer::explore::exploration_phase;
    use sparrow::optimizer::lbf::LBFBuilder;
    use sparrow::optimizer::separator::Separator;
    use sparrow::util::io;
    use sparrow::util::terminator::BasicTerminator;
    use sparrow::util::terminator::Terminator;
    use std::path::Path;
    use std::time::Duration;
    use rand::rngs::Xoshiro256PlusPlus;
    use rand::SeedableRng;
    use test_case::test_case;
    use sparrow::util::listener::DummySolListener;

    const EXPLORE_TIMEOUT: Duration = Duration::from_secs(10);
    const COMPRESS_TIMEOUT: Duration = Duration::from_secs(10);
    const INSTANCE_BASE_PATH: &str = "data/input";
    const RNG_SEED: Option<usize> = Some(0); // fix seed for reproducibility

    #[test_case("swim.json"; "swim")]
    #[test_case("shirts.json"; "shirts")]
    #[test_case("trousers.json"; "trousers")]
    fn simulate_optimization(path: &str) -> Result<()> {
        let config = DEFAULT_SPARROW_CONFIG;
        let input_file_path = format!("{INSTANCE_BASE_PATH}/{path}");
        let (mut json_instance, _) = io::read_spp_input(Path::new(&input_file_path))?;

        for (idx, item) in json_instance.items.iter_mut().enumerate() {
            item.base.id = 100 + idx as u64 * 7;
        }
        let importer = Importer::new(config.cde_config, config.poly_simpl_tolerance, config.narrow_concavity_cutoff_ratio);
        let instance = jagua_rs::probs::spp::io::import_instance(&importer, &json_instance)?;

        println!("[TEST] loaded instance: {}", json_instance.name);

        let rng = match RNG_SEED {
            Some(seed) => {
                println!("[TEST] using provided seed: {}", seed);
                Xoshiro256PlusPlus::seed_from_u64(seed as u64)
            }
            None => {
                let seed = rand::random();
                println!("[TEST] no seed provided, using: {}", seed);
                Xoshiro256PlusPlus::seed_from_u64(seed)
            }
        };

        let mut terminator = BasicTerminator::new();
        let mut sol_listener = DummySolListener;
        terminator.new_timeout(EXPLORE_TIMEOUT);

        let builder = LBFBuilder::new(instance.clone(), rng, LBF_SAMPLE_CONFIG)?.construct()?;
        let exported = jagua_rs::probs::spp::io::export(&builder.prob.save(), *sparrow::EPOCH);
        let restored = jagua_rs::probs::spp::io::import_solution(&instance, &exported)?;
        assert!(jagua_rs::entities::Layout::from_snapshot(restored.layout_snapshot()).is_collision_free());
        assert_eq!(restored.layout_snapshot().placed_items().len(), instance.total_item_qty());
        let mut separator = Separator::new(builder.prob, builder.rng, config.expl_cfg.separator_config);

        let sols = exploration_phase(&mut separator, &mut sol_listener, &terminator, &config.expl_cfg);
        let final_explore_sol = sols.last().expect("no solutions found during exploration");

        terminator.new_timeout(COMPRESS_TIMEOUT);
        compression_phase(&mut separator, final_explore_sol, &mut sol_listener, &terminator, &config.cmpr_cfg);
        Ok(())
    }
}

/// Tilvora multi-sheet mode: the same search on fixed-size sheets separated by blocking bars.
#[cfg(test)]
mod sheet_tests {
    use anyhow::Result;
    use jagua_rs::geometry::geo_traits::Transformable;
    use jagua_rs::io::import::Importer;
    use rand::SeedableRng;
    use rand::rngs::Xoshiro256PlusPlus;
    use sparrow::config::DEFAULT_SPARROW_CONFIG;
    use sparrow::consts::LBF_SAMPLE_CONFIG;
    use sparrow::optimizer::compress::compression_phase;
    use sparrow::optimizer::explore::exploration_phase;
    use sparrow::optimizer::lbf::LBFBuilder;
    use sparrow::optimizer::problem::{StripLike, StripSolution};
    use sparrow::optimizer::separator::Separator;
    use sparrow::sheet::io::{ExtSheet, ExtSheetInstance, export, import_instance};
    use sparrow::util::io;
    use sparrow::util::listener::DummySolListener;
    use sparrow::util::terminator::{BasicTerminator, Terminator};
    use std::collections::HashMap;
    use std::path::Path;
    use std::time::Duration;

    /// Builds a multi-sheet instance from an ESICUP strip instance: sheets `width_ratio` strip heights wide.
    fn sheet_instance(path: &str, width_ratio: f32, margin_ratio: f32, kerf_ratio: f32) -> Result<ExtSheetInstance> {
        let (json_instance, _) = io::read_spp_input(Path::new(&format!("data/input/{path}")))?;
        let h = json_instance.strip_height;
        Ok(ExtSheetInstance {
            name: format!("{}_sheet", json_instance.name),
            min_item_separation: kerf_ratio * h,
            items: json_instance.items,
            sheet: ExtSheet {
                width: Some(width_ratio * h),
                height: h,
                margin: margin_ratio * h,
                gap: 0.0,
                count: None,
            },
        })
    }

    fn run(ext: &ExtSheetInstance, explore: Duration, compress: Duration) -> Result<sparrow::sheet::SheetSolution> {
        let config = DEFAULT_SPARROW_CONFIG;
        let importer = Importer::new(config.cde_config, config.poly_simpl_tolerance, config.narrow_concavity_cutoff_ratio);
        let prob = import_instance(&importer, ext)?;
        let rng = Xoshiro256PlusPlus::seed_from_u64(0);
        let mut terminator = BasicTerminator::new();
        let mut listener = DummySolListener;

        let builder = LBFBuilder::from_problem(prob, rng, LBF_SAMPLE_CONFIG).construct()?;
        assert!(jagua_rs::entities::Layout::from_snapshot(builder.prob.save().layout_snapshot()).is_collision_free());
        let mut separator = Separator::new(builder.prob, builder.rng, config.expl_cfg.separator_config);

        terminator.new_timeout(explore);
        let sols = exploration_phase(&mut separator, &mut listener, &terminator, &config.expl_cfg);
        let final_explore_sol = sols.last().expect("no solutions found during exploration");
        terminator.new_timeout(compress);
        Ok(compression_phase(&mut separator, final_explore_sol, &mut listener, &terminator, &config.cmpr_cfg))
    }

    /// Independent check of the exported solution: every original shape inside its sheet's usable
    /// region, no collision (jagua-rs CDE incl. bars), every demand met exactly.
    fn check_export(ext: &ExtSheetInstance, solution: &sparrow::sheet::SheetSolution) {
        let exported = export(solution, *sparrow::EPOCH);
        let geom = solution.geometry();
        // the strip width may reach into a sheet that holds nothing; exported sheets are the used ones
        assert!(exported.sheet_count <= geom.n_sheets, "{} > {}", exported.sheet_count, geom.n_sheets);
        assert_eq!(exported.sheets.len(), exported.sheet_count);
        assert!(exported.sheets.iter().all(|s| !s.placed_items.is_empty()), "no empty sheet in the export");
        assert!(jagua_rs::entities::Layout::from_snapshot(solution.layout_snapshot()).is_collision_free());

        let spec = solution.spec();
        let (w, h, m) = (spec.width.unwrap(), spec.height, spec.margin);
        let tol = 1e-4 * h;
        let shapes: HashMap<u64, Vec<(f32, f32)>> = ext.items.iter()
            .map(|it| {
                let pts = match &it.base.shape {
                    jagua_rs::io::ext_repr::ExtShape::SimplePolygon(sp) => sp.0.clone(),
                    other => panic!("unexpected shape {:?}", std::mem::discriminant(other)),
                };
                (it.base.id, pts)
            })
            .collect();
        let mut counts: HashMap<u64, u64> = HashMap::new();
        let mut total_used = 0.0f32;
        for sheet in &exported.sheets {
            assert!(sheet.used_width <= w - m + tol, "sheet {} used width {} exceeds usable", sheet.index, sheet.used_width);
            total_used = total_used.max(sheet.used_width);
            for pi in &sheet.placed_items {
                *counts.entry(pi.item_id).or_default() += 1;
                let dt: jagua_rs::geometry::DTransformation = pi.transformation.clone().into();
                let pts = &shapes[&pi.item_id];
                let poly = jagua_rs::geometry::primitives::SPolygon::new(
                    pts.iter().map(|(x, y)| jagua_rs::geometry::primitives::Point(*x, *y)).collect()
                ).unwrap().transform_clone(&dt.compose());
                let b = poly.bbox();
                assert!(b.x_min >= m - tol && b.x_max <= w - m + tol && b.y_min >= m - tol && b.y_max <= h - m + tol,
                    "item {} on sheet {} outside usable region: {:?} (w {w}, h {h}, m {m})", pi.item_id, sheet.index, b);
            }
        }
        for it in &ext.items {
            assert_eq!(counts.get(&it.base.id).copied().unwrap_or(0), it.demand, "demand of item {}", it.base.id);
        }
        assert!(exported.sheets.last().unwrap().placed_items.len() > 0, "last sheet must not be empty");
        assert!(exported.remainder.is_some());
        assert!(exported.density > 0.0 && exported.density <= 1.0);
    }

    #[test]
    fn sheets_with_margin_and_kerf_are_respected() -> Result<()> {
        // Sheets one strip height wide: swim's strip is longer than one height, so at least 2 sheets
        // (exercises a bar with margin and kerf).
        let ext = sheet_instance("swim.json", 1.0, 0.01, 0.005)?;
        let sol = run(&ext, Duration::from_secs(8), Duration::from_secs(4))?;
        check_export(&ext, &sol);
        assert!(sol.geometry().n_sheets >= 2, "swim should need several sheets one strip height wide, got {}", sol.geometry().n_sheets);
        Ok(())
    }

    #[test]
    fn sheets_without_margin_or_kerf() -> Result<()> {
        let ext = sheet_instance("shirts.json", 2.5, 0.0, 0.0)?;
        let sol = run(&ext, Duration::from_secs(8), Duration::from_secs(4))?;
        check_export(&ext, &sol);
        Ok(())
    }

    /// The sheet-by-sheet greedy builder yields a feasible start (every item inside one sheet, no
    /// collisions) and the optimizer can warm start from it with the tail-only split.
    #[test]
    fn greedy_start_is_feasible_and_warm_starts() -> Result<()> {
        use sparrow::sheet::SplitMode;
        use sparrow::sheet::greedy::{construct_greedy, DEFAULT_GREEDY_CONFIG};
        use sparrow::optimizer::optimize_problem;

        let ext = sheet_instance("swim.json", 1.0, 0.01, 0.005)?;
        let config = DEFAULT_SPARROW_CONFIG;
        let importer = Importer::new(config.cde_config, config.poly_simpl_tolerance, config.narrow_concavity_cutoff_ratio);
        let prob = import_instance(&importer, &ext)?.with_split_mode(SplitMode::TailCenter);

        let lbf = LBFBuilder::from_problem(prob.clone(), Xoshiro256PlusPlus::seed_from_u64(0), LBF_SAMPLE_CONFIG).construct()?;
        let lbf_sol = lbf.prob.save();
        let (built, stats) = construct_greedy(prob, Xoshiro256PlusPlus::seed_from_u64(0), DEFAULT_GREEDY_CONFIG)?;
        let greedy_sol = built.save();
        println!("[TEST] swim sheets: lbf {} ({:.2}%), greedy {} ({:.2}%) in {:?}, {} evals",
            lbf_sol.geometry().n_sheets, lbf_sol.density() * 100.0,
            greedy_sol.geometry().n_sheets, greedy_sol.density() * 100.0, stats.elapsed, stats.n_evals);
        assert_eq!(built.n_placed_items(), built.total_item_qty());
        check_export(&ext, &greedy_sol);
        assert_eq!(stats.n_sheets, greedy_sol.geometry().n_sheets);
        assert!(stats.n_sheets >= 2);

        // warm start: exploration + compression from the greedy solution
        let mut terminator = BasicTerminator::new();
        let mut listener = DummySolListener;
        let mut expl_cfg = config.expl_cfg;
        expl_cfg.time_limit = Duration::from_secs(4);
        let mut cmpr_cfg = config.cmpr_cfg;
        cmpr_cfg.time_limit = Duration::from_secs(2);
        let final_sol = optimize_problem(built, Xoshiro256PlusPlus::seed_from_u64(1), &mut listener, &mut terminator, &expl_cfg, &cmpr_cfg, Some(&greedy_sol))?;
        check_export(&ext, &final_sol);
        assert!(final_sol.strip_width() <= greedy_sol.strip_width() + 1e-3, "warm started search must not end wider than its start");
        Ok(())
    }

    /// The sheet optimizer (exploration + tail compression) ends feasible and never wider than its start.
    #[test]
    fn tail_compression_keeps_feasibility() -> Result<()> {
        use sparrow::sheet::compress::{optimize_sheets, SheetCompression};
        use sparrow::sheet::greedy::{construct_greedy, DEFAULT_GREEDY_CONFIG};

        let ext = sheet_instance("shirts.json", 2.0, 0.005, 0.002)?;
        let config = DEFAULT_SPARROW_CONFIG;
        let importer = Importer::new(config.cde_config, config.poly_simpl_tolerance, config.narrow_concavity_cutoff_ratio);
        let prob = import_instance(&importer, &ext)?;
        let (built, _) = construct_greedy(prob, Xoshiro256PlusPlus::seed_from_u64(2), DEFAULT_GREEDY_CONFIG)?;
        let start_sol = built.save();
        let mut terminator = BasicTerminator::new();
        let mut listener = DummySolListener;
        let mut expl_cfg = config.expl_cfg;
        expl_cfg.time_limit = Duration::from_secs(4);
        let mut cmpr_cfg = config.cmpr_cfg;
        cmpr_cfg.time_limit = Duration::from_secs(4);
        let final_sol = optimize_sheets(built, Xoshiro256PlusPlus::seed_from_u64(3), &mut listener, &mut terminator, &expl_cfg, &cmpr_cfg, Some(&start_sol), SheetCompression::Tail)?;
        check_export(&ext, &final_sol);
        assert!(final_sol.strip_width() <= start_sol.strip_width() + 1e-3 * ext.sheet.height);
        let exported = export(&final_sol, *sparrow::EPOCH);
        println!("[TEST] shirts sheets: start {} -> final {} (tail used {:.1})", start_sol.geometry().n_sheets, exported.sheet_count, final_sol.tail_usage().1);
        Ok(())
    }

    /// A strip width reaching into a sheet that holds nothing must not count that sheet.
    #[test]
    fn export_drops_trailing_empty_sheets() -> Result<()> {
        use sparrow::sheet::greedy::{construct_greedy, DEFAULT_GREEDY_CONFIG};

        let ext = sheet_instance("trousers.json", 3.0, 0.0, 0.0)?;
        let config = DEFAULT_SPARROW_CONFIG;
        let importer = Importer::new(config.cde_config, config.poly_simpl_tolerance, config.narrow_concavity_cutoff_ratio);
        let prob = import_instance(&importer, &ext)?;
        let (mut built, _) = construct_greedy(prob, Xoshiro256PlusPlus::seed_from_u64(0), DEFAULT_GREEDY_CONFIG)?;
        let used = built.geometry().n_sheets;
        // widen the strip by two empty sheets
        let wide = built.width_for_sheets(used + 2);
        built.change_strip_width(wide)?;
        let sol = built.save();
        assert_eq!(sol.geometry().n_sheets, used + 2);
        let exported = export(&sol, *sparrow::EPOCH);
        assert_eq!(exported.sheet_count, used, "empty trailing sheets must not be exported");
        assert_eq!(exported.sheets.len(), used);
        assert_eq!(exported.remainder.as_ref().unwrap().sheet, used - 1);
        check_export(&ext, &sol);
        Ok(())
    }

    #[test]
    fn export_and_strip_width_agree() -> Result<()> {
        let ext = sheet_instance("trousers.json", 2.5, 0.005, 0.0)?;
        let sol = run(&ext, Duration::from_secs(5), Duration::from_secs(3))?;
        let exported = export(&sol, *sparrow::EPOCH);
        let spec = sol.spec();
        assert!(exported.sheet_count <= sol.geometry().n_sheets);
        // last_sheet_used_width + sheet offset must not exceed the strip width (usable right edge)
        let offset = (exported.sheet_count - 1) as f32 * spec.pitch().unwrap();
        assert!(exported.last_sheet_used_width + offset <= sol.strip_width() + 1e-3 * spec.height,
            "used {} + offset {} > strip width {}", exported.last_sheet_used_width, offset, sol.strip_width());
        Ok(())
    }
}
