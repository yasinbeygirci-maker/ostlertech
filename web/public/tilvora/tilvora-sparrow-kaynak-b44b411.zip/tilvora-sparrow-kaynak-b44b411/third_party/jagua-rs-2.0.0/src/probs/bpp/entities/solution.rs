use crate::Instant;
use crate::entities::LayoutSnapshot;
use crate::probs::bpp::entities::{BPInstance, LayKey};
use slotmap::SecondaryMap;

/// Snapshot of [`BPProblem`](crate::probs::bpp::entities::BPProblem) at a specific moment.
/// Can be used to restore to a previous state.
#[derive(Debug, Clone)]
pub struct BPSolution {
    /// Layout snapshots keyed by their keys at capture time.
    pub(crate) layout_snapshots: SecondaryMap<LayKey, LayoutSnapshot>,
    /// Source bin index for each layout.
    pub(crate) layout_bins: SecondaryMap<LayKey, usize>,
    /// Instant the solution was created
    pub time_stamp: Instant,
}

impl BPSolution {
    #[must_use]
    pub fn layout_snapshots(&self) -> &SecondaryMap<LayKey, LayoutSnapshot> {
        &self.layout_snapshots
    }

    #[must_use]
    pub fn layout_bins(&self) -> &SecondaryMap<LayKey, usize> {
        &self.layout_bins
    }

    #[must_use]
    pub fn density(&self) -> f32 {
        let total_bin_area = self
            .layout_snapshots
            .values()
            .map(|ls| ls.container.area())
            .sum::<f32>();

        let total_item_area = self
            .layout_snapshots
            .values()
            .map(LayoutSnapshot::placed_item_area)
            .sum::<f32>();

        total_item_area / total_bin_area
    }

    #[must_use]
    pub fn cost(&self, instance: &BPInstance) -> u64 {
        self.layout_bins
            .values()
            .map(|idx| instance.bins[*idx].cost)
            .sum()
    }
}
