//! Tail-focused compression for the multi-sheet problem (Tilvora addition, MIT).
//!
//! Sparrow's compression shrinks the strip by 0.05% → 0.001% of its width (300 → 6 mm on a 600 m
//! strip of 100 sheets). On fixed sheets that only trims the remainder of the last sheet by a few
//! hundred millimetres and never removes a sheet, which is the objective that matters. Here the
//! compression budget is spent on dropping the last sheet: the first attempt removes the whole tail
//! (every item of the last sheet has to find room elsewhere), on failure half of the tail's used
//! width, then a quarter, ... down to 1/32; every success starts again with the whole new tail, and
//! when the smallest step fails the cycle restarts (the separator is randomized, a retry can succeed).

use crate::config::{CompressionConfig, ExplorationConfig};
use crate::consts::LBF_SAMPLE_CONFIG;
use crate::optimizer::compress::compression_phase;
use crate::optimizer::explore::exploration_phase;
use crate::optimizer::lbf::LBFBuilder;
use crate::optimizer::problem::{StripLike, StripSolution};
use crate::optimizer::separator::Separator;
use crate::optimizer::strip_width_lower_bound;
use crate::sheet::{SheetProblem, SheetSolution};
use crate::util::listener::{OptimizationPhase, ReportType, SolutionListener};
use crate::util::terminator::Terminator;
use jagua_rs::Instant;
use log::info;
use rand::rngs::Xoshiro256PlusPlus;
use rand::{Rng, SeedableRng};

/// Smallest part of the tail's used width that is still attempted.
pub const MIN_TAIL_FRACTION: f32 = 1.0 / 32.0;

/// What the second phase does in multi-sheet mode.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum SheetCompression {
    /// No separate compression: the exploration (sheet-sized shrink steps) runs for the whole budget.
    /// Measured on the 1030-item instance (3 seeds × 15 min): explore 101/101/101 sheets, tail 102/101/102;
    /// strip compression only trims the remainder (~0.3% density) and never drops a sheet.
    #[default]
    Explore,
    /// Try to drop the last sheet, then halves of its used width ([`tail_compression_phase`]).
    Tail,
    /// Sparrow's relative compression (0.05% → 0.001% of the strip width), for comparison.
    Strip,
}

impl std::str::FromStr for SheetCompression {
    type Err = String;

    fn from_str(s: &str) -> std::result::Result<Self, Self::Err> {
        match s {
            "explore" => Ok(Self::Explore),
            "tail" => Ok(Self::Tail),
            "strip" => Ok(Self::Strip),
            other => Err(format!("unknown sheet compression '{other}' (explore | tail | strip)")),
        }
    }
}

/// Sparrow's optimize loop for sheets: exploration (shared code) followed by the chosen second phase.
///
/// `prob` must be empty when no `initial_solution` is given; with one, `prob` is restored to it.
pub fn optimize_sheets(
    prob: SheetProblem,
    mut rng: Xoshiro256PlusPlus,
    sol_listener: &mut impl SolutionListener<SheetSolution>,
    terminator: &mut impl Terminator,
    expl_config: &ExplorationConfig,
    cmpr_config: &CompressionConfig,
    initial_solution: Option<&SheetSolution>,
    mode: SheetCompression,
) -> anyhow::Result<SheetSolution> {
    let mut next_rng = || Xoshiro256PlusPlus::seed_from_u64(rng.next_u64());
    let mut expl_config = *expl_config;
    if mode == SheetCompression::Explore {
        expl_config.time_limit += cmpr_config.time_limit;
        info!("[OPT] multi-sheet: exploration takes the whole budget ({:.0}s), no compression phase", expl_config.time_limit.as_secs_f64());
    }

    let start_prob = match initial_solution {
        None => LBFBuilder::from_problem(prob, next_rng(), LBF_SAMPLE_CONFIG).construct()?.prob,
        Some(init_sol) => {
            info!("[OPT] warm starting from provided initial solution");
            let mut prob = prob;
            prob.restore(init_sol);
            prob
        }
    };

    sol_listener.report_phase(OptimizationPhase::Exploration);
    terminator.new_timeout(expl_config.time_limit);
    let mut expl_separator = Separator::new(start_prob, next_rng(), expl_config.separator_config);
    let solutions = exploration_phase(&mut expl_separator, sol_listener, terminator, &expl_config);
    let final_explore_sol = solutions.into_iter().last().unwrap();

    let final_sol = match mode {
        SheetCompression::Explore => final_explore_sol,
        SheetCompression::Tail | SheetCompression::Strip => {
            sol_listener.report_phase(OptimizationPhase::Compression);
            terminator.new_timeout(cmpr_config.time_limit);
            let mut cmpr_separator = Separator::new(expl_separator.prob, next_rng(), cmpr_config.separator_config);
            if mode == SheetCompression::Tail {
                tail_compression_phase(&mut cmpr_separator, &final_explore_sol, sol_listener, terminator)
            } else {
                compression_phase(&mut cmpr_separator, &final_explore_sol, sol_listener, terminator, cmpr_config)
            }
        }
    };

    sol_listener.report(ReportType::Final, &final_sol);
    Ok(final_sol)
}

/// Tries to drop the last sheet, then ever smaller parts of its used width, until time runs out.
pub fn tail_compression_phase(
    sep: &mut Separator<SheetProblem>,
    init_sol: &SheetSolution,
    sol_listener: &mut impl SolutionListener<SheetSolution>,
    term: &impl Terminator,
) -> SheetSolution {
    let width_lower_bound = strip_width_lower_bound(&sep.prob);
    let start = Instant::now();
    let mut best = init_sol.clone();
    let mut fraction = 1.0f32;
    let (mut n_ok, mut n_fail) = (0, 0);

    while !term.kill() {
        let geom = best.geometry();
        let spec = *best.spec();
        let (tail_start, tail_used) = best.tail_usage();
        let target = if fraction >= 1.0 {
            // drop the last sheet entirely: the strip ends at the usable right edge of the one before
            if geom.n_sheets < 2 {
                break;
            }
            spec.usable_x_max(geom.n_sheets - 2).unwrap_or(best.strip_width())
        } else {
            tail_start + tail_used - fraction * tail_used
        };
        if target < width_lower_bound || target >= best.strip_width() {
            info!("[CMPR] tail target {:.3} not below current width {:.3} / lower bound {:.3}, stopping", target, best.strip_width(), width_lower_bound);
            break;
        }
        sol_listener.report_compression_progress(fraction);
        info!("[CMPR] tail attempt: {} sheets, tail used {:.1}, fraction {:.4}: width {:.3} -> {:.3}", geom.n_sheets, tail_used, fraction, best.strip_width(), target);

        // Restore the best solution at its own width, then shrink to the target: the items of the
        // right half of the tail follow the edge (tail-center split), the rest stays and collides
        // with the new right edge or the bar.
        if sep.change_strip_width(best.strip_width(), None).is_err() {
            break;
        }
        sep.rollback(&best, None);
        let split = sep.prob.explore_split_position();
        if sep.change_strip_width(target, Some(split)).is_err() {
            break;
        }
        let (sol, ct) = sep.separate(term, sol_listener);
        if ct.get_total_loss() == 0.0 {
            n_ok += 1;
            info!("[CMPR] tail success: width {:.3} ({:.3}%), sheets {}", sol.strip_width(), sol.density() * 100.0, sol.geometry().n_sheets);
            sol_listener.report(ReportType::CmprFeas, &sol);
            best = sol;
            fraction = 1.0;
        } else {
            n_fail += 1;
            info!("[CMPR] tail failed at fraction {:.4} (min loss {:.1})", fraction, ct.get_total_loss());
            fraction /= 2.0;
            if fraction < MIN_TAIL_FRACTION {
                fraction = 1.0;
            }
        }
    }
    info!("[CMPR] tail compression finished: {} ok, {} failed, {:.3}s; {} sheets, tail used {:.1}, density {:.3}% -> {:.3}%",
        n_ok, n_fail, start.elapsed().as_secs_f64(), best.geometry().n_sheets, best.tail_usage().1,
        init_sol.density() * 100.0, best.density() * 100.0);
    best
}
