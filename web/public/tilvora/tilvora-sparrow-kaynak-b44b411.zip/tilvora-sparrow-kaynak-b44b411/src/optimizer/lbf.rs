use crate::eval::lbf_evaluator::LBFEvaluator;
use crate::eval::sample_eval::SampleEval;
use crate::optimizer::problem::StripLike;
use crate::sample::search::{search_placement, SampleConfig};
use itertools::Itertools;
use jagua_rs::probs::spp::entities::{SPInstance, SPPlacement, SPProblem};
use jagua_rs::Instant;
use log::debug;
use ordered_float::OrderedFloat;
use std::cmp::Reverse;
use std::iter;
use rand::rngs::Xoshiro256PlusPlus;

/// The initial-placement heuristic could not construct a solution.
/// This is not a proof that the instance is infeasible.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ConstructionError {
    /// The item's ID in the input instance.
    pub external_id: u64,
}

impl std::fmt::Display for ConstructionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "could not construct an initial placement for item {}", self.external_id)
    }
}

impl std::error::Error for ConstructionError {}

pub struct LBFBuilder<P: StripLike = SPProblem> {
    pub prob: P,
    pub rng: Xoshiro256PlusPlus,
    pub sample_config: SampleConfig,
}

impl LBFBuilder<SPProblem> {
    pub fn new(
        instance: SPInstance,
        rng: Xoshiro256PlusPlus,
        sample_config: SampleConfig,
    ) -> anyhow::Result<Self> {
        Ok(Self::from_problem(SPProblem::new(instance)?, rng, sample_config))
    }
}

impl<P: StripLike> LBFBuilder<P> {
    /// Starts from an empty problem of any [`StripLike`] kind.
    pub fn from_problem(prob: P, rng: Xoshiro256PlusPlus, sample_config: SampleConfig) -> Self {
        Self {
            prob,
            rng,
            sample_config,
        }
    }

    /// Builds a complete initial placement.
    ///
    /// Returns an error if strip growth reaches the heuristic limit.
    pub fn construct(mut self) -> anyhow::Result<Self> {
        let start = Instant::now();
        let n_items = self.prob.items().len();
        let sorted_item_indices = (0..n_items)
            .sorted_by_cached_key(|id| {
                let item_shape = self.prob.item(*id).shape_cd().as_ref();
                let convex_hull_area = item_shape.surrogate().convex_hull_area;
                let diameter = item_shape.diameter();
                Reverse(OrderedFloat(convex_hull_area * diameter))
            })
            .flat_map(|id| {
                let missing_qty = self.prob.item_demand_qtys()[id];
                iter::repeat_n(id, missing_qty)
            })
            .collect_vec();

        debug!("[CONSTR] placing items in order: {:?}",sorted_item_indices);

        for item_idx in sorted_item_indices {
            self.place_item(item_idx)?;
        }

        self.prob.fit_strip()?;
        debug!("[CONSTR] placed all items in width: {:.3} (in {:?})",self.prob.strip_width(), start.elapsed());
        Ok(self)
    }

    fn place_item(&mut self, item_idx: usize) -> anyhow::Result<()> {
        loop {
            if let Some(placement) = self.find_placement(item_idx) {
                self.prob.place_item(placement);
                debug!("[CONSTR] placing item {}/{} with idx {} at [{}]", self.prob.layout().placed_items().len(), self.prob.total_item_qty(), placement.item_idx, placement.d_transf);
                return Ok(());
            }

            let next_width = self.prob.strip_width() * 1.2;
            // Retain the existing heuristic ceiling, without treating it as infeasibility.
            let width_limit = 2.0 * self.prob.items().iter()
                .map(|(item, qty)| item.shape_cd().diameter() * *qty as f32)
                .sum::<f32>();
            if next_width >= width_limit {
                let external_id = self.prob.item(item_idx).external_id();
                return Err(ConstructionError { external_id }.into());
            }
            debug!("[CONSTR] failed to place item with idx {}, expanding strip width", item_idx);
            self.prob.change_strip_width(next_width)?;
        }
    }

    fn find_placement(&mut self, item_idx: usize) -> Option<SPPlacement> {
        let layout = self.prob.layout();
        let item = self.prob.item(item_idx);
        let evaluator = LBFEvaluator::new(layout, item);

        let (best_sample, _) = search_placement(layout, item, None, evaluator, self.sample_config, &mut self.rng);

        match best_sample {
            Some((d_transf, SampleEval::Clear { .. })) => {
                Some(SPPlacement { item_idx, d_transf })
            }
            _ => None
        }
    }
}
