pub(crate) mod best_samples;
pub(crate) mod coord_descent;
pub mod search;
pub mod uniform_sampler;