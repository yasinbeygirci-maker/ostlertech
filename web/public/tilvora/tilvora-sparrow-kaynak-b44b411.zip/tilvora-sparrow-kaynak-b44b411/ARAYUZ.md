# Tilvora çok levha kipi: `sparrow.exe` JSON arayüzü

Durum: 2026-11-08, Can. (Sparrow `ca4ee65` + jagua-rs 2.0.0 crates.io, jagua-rs dosyası DEĞİŞTİRİLMEDİ). Kotlin katmanı bu belgeye göre bağlanır.

## Çağrı

```
sparrow.exe -i <girdi.json> -t <saniye> [-s <tohum>] [--workers <n>] [-o <çıktı-klasörü>]
```

- `-t`: toplam süre (yüzde 80 arama, yüzde 20 sıkıştırma). `-e <sn> -c <sn>` ile ayrı da verilir.
- `-o`: `log.txt`, `final_<ad>.json`, `final_<ad>.svg` ve ara çözüm SVG'leri (`sols_<ad>/`) buraya yazılır. Verilmezse çalışma klasöründe `output/`.
- Çıkış kodu: `0` tamam · `1` hata (girdi bozuk, parça hiçbir levhaya sığmıyor, ilk yerleşim kurulamadı; mesaj stderr'de `Error: ...`) · `3` çözüm `sheet.count` sınırını aştı (JSON yine yazılır, `sheet_limit_exceeded: true`).
- Ctrl+C / `SIGINT`: Sparrow'un kendi davranışı (aşamayı erken bitirir; ikinci sinyal durdurur). Kotlin tarafı süreci öldürmeden önce bunu kullanabilir, ama en güvenlisi `-t` ile süre vermektir.
- Girdide `sheet` nesnesi varsa çok levha kipi; yoksa Sparrow'un özgün şerit (strip) kipi çalışır (format ve çıktı üst kaynaktaki gibi, `-o` orada da geçerli).

## Girdi (çok levha)

```json
{
  "name": "is-123",
  "min_item_separation": 4.0,
  "sheet": { "width": 6000, "height": 3210, "margin": 10, "gap": 0, "count": null },
  "items": [
    {
      "id": 7,
      "demand": 3,
      "orientation": { "rotation": { "mode": "discrete", "angles": [0, 90, 180, 270] } },
      "shape": { "type": "simple_polygon", "data": [[0,0],[1200,0],[1200,800],[0,800]] }
    }
  ]
}
```

| Alan | Anlam |
|---|---|
| `min_item_separation` | kerf / parçalar arası en küçük mesafe. Yalnız parça-parça arasında; levha kenarında kerf düşülmez (kenar için `margin`). 0 ya da yok = yok. |
| `sheet.width` | levha eni (x, şerit doğrultusu). `null` = tek sınırsız levha (şerit eşdeğeri). |
| `sheet.height` | levha boyu (y). |
| `sheet.margin` | kenar payı; parçalar her kenardan en az bu kadar içte (varsayılan 0). |
| `sheet.gap` | levhalar arası ölü boşluk, levhanın DIŞINDA; yalnız iç model için, genelde 0 bırak. Motor çubuğun geçerli bir çokgen kalması için gerekirse kendisi büyütür: `gap = max(gap, 2·kerf − 2·margin + 0,001·width)`; kullanılan değer çıktıdaki `solution.sheet.gap`'te. |
| `sheet.count` | eldeki levha adedi (`null` = sınırsız). Yalnız sonuçta denetlenir (çıkış kodu 3). |
| `items[].id` | benzersiz tam sayı; çıktı bu kimliğe göre eşlenir. |
| `items[].demand` | adet (0 olanlar atlanır). |
| `items[].orientation.rotation` | `discrete` + `angles` (derece) ya da `{"mode":"continuous"}` ya da `{"mode":"stepped","step":15}`. Yön kısıtı (damar): izinli açı listesini daraltarak. İsteğe bağlı `reflection_axes` (aynalama) jagua-rs'teki gibi. |
| `items[].shape` | `simple_polygon` (delik yok; delikli parça reddedilir), `rectangle` (`{"x_min","y_min","width","height"}`) ya da `polygon` (`outer` + boş `inner`). Yay yok; dışarıdan çokgenle yaklaştır. Birim serbest (mm önerilir), her yerde aynı. |

Tek levha türü desteklenir (ilk sürüm). Farklı boyutlar/kalınlıklar ayrı çağrı.

## Çıktı (`final_<ad>.json`)

Girdinin tüm alanları aynen + `solution`:

```json
"solution": {
  "sheet_count": 3,
  "sheet": { "width": 6000, "height": 3210, "margin": 10, "gap": 0, "count": null },
  "density": 0.874,
  "usable_density": 0.886,
  "last_sheet_used_width": 2345.6,
  "remainder": { "sheet": 2, "x_min": 2345.6, "x_max": 5990, "y_min": 10, "y_max": 3200, "area": 11625636 },
  "sheet_limit_exceeded": false,
  "strip_width": 14355.6,
  "run_time_sec": 598,
  "sheets": [
    { "index": 0, "density": 0.93, "used_width": 5990,
      "placed_items": [ { "item_id": 7, "transformation": { "rotation": 90, "translation": [1234.5, 876.2] } } ] }
  ]
}
```

| Alan | Anlam |
|---|---|
| `sheet_count` | kullanılan levha sayısı. Amaç: önce levha sayısı, sonra son levhanın kullanılan eni en az (artık tek dikdörtgen parça). |
| `density` | toplam parça alanı / (levha sayısı × width × height). `usable_density`: kenar payı düşülmüş alana göre. |
| `last_sheet_used_width` | son levhada parçaların en sağ noktası (levha yerel x). |
| `remainder` | son levhanın kullanılmayan dikdörtgeni (yerel koordinat). `width: null` ise `null`. |
| `sheets[].index` | 0'dan başlar; levha sırası = sol→sağ, son levha artıklı. |
| `sheets[].used_width` | o levhadaki parçaların en sağ noktası. Dolu levhalarda ≈ `width − margin`. |
| `placed_items[].transformation` | parçanın `shape.data` noktalarına uygulanır: (varsa `reflected: true` ise y → −y) → `rotation` derece saat yönünün tersine, orijin etrafında → `translation` ekle. x LEVHA YEREL (levhanın sol kenarı 0), y levha alt kenarı 0. Bu dönüşüm jagua-rs'in SVG/JSON'daki ile aynıdır; yalnız x'ten `index × (width + gap)` düşülmüştür. |
| `strip_width` | iç tanı değeri (şerit koordinatı); Kotlin'in işi yok. |

Hassasiyet: motor f32 çalışır; toplam şerit uzunluğu (levha sayısı × en) 600 m'de koordinat yuvarlaması ~0,05 mm, 6 km'de ~0,5 mm olur. Çok büyük işi (≫100 levha) kalınlık/parti bazında ayrı çağrılara böl. Bağımsız doğrulayıcı `dogrulayici\dogrula.py` 0,05 mm tolerans kullanır.

## Doğrulama

```
python dogrulayici\dogrula.py final_<ad>.json [--tol 0.05]
```
Çıkış 0 = ihlal yok. Kontroller: parça levha kullanılabilir bölgesinde, aynı levhada çakışma yok ve mesafe ≥ kerf, adet = talep, açı izinli. Kotlin katmanı aynı kontrolleri kendi doğrulayıcısında da yapmalı (motor çıktısına güvenme).

## Kotlin tarafı için notlar

- Girdi JSON'u yaz → süreç başlat (`-o` ile iş klasörü) → çıkış kodunu oku → `final_<ad>.json` oku → doğrula → DXF/ekrana çiz.
- `name` dosya adına giriyor: yalnız ASCII harf/rakam/`-`/`_` kullan.
- Parça sığmıyorsa süreç hemen `Error: items do not fit in a sheet in any allowed rotation (external ids): [..]` ile çıkar (kod 1); kimlikleri kullanıcıya göster.
- Aynı tohum (`-s`) + aynı süre tam tekrar üretmez (süreye bağlı durma); kıyas için birkaç tohum çalıştır.
- Şerit kipi (eski yöntem: şerit + bölme) hâlâ çalışır; girdide `sheet` yoksa.
