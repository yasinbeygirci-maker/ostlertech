//! Sheet-by-sheet greedy constructor for the multi-sheet problem (Tilvora addition, MIT).
//!
//! Sparrow's left-bottom-fill constructor samples the whole strip. With ~100 sheets side by side
//! its 1000 samples spread so thinly that the start solution is poor (~79% density on the glass
//! instance) and the search spends its budget catching up. This builder is a first-fit-decreasing
//! bin packing heuristic with Sparrow's left-bottom sampling inside ONE sheet at a time: items are
//! sorted by decreasing size, each is tried on the open sheets in order and placed at the
//! left-bottom-most collision-free sample found (refined by coordinate descent); when no open sheet
//! takes it, a new sheet is opened at the end of the strip.

use crate::consts::UNIQUE_SAMPLE_THRESHOLD;
use crate::eval::lbf_evaluator::LBFEvaluator;
use crate::eval::sample_eval::{SampleEval, SampleEvaluator};
use crate::optimizer::lbf::ConstructionError;
use crate::optimizer::problem::StripLike;
use crate::sample::best_samples::BestSamples;
use crate::sample::coord_descent::refine_coord_desc;
use crate::sample::search::{final_refine_cd_config, prerefine_cd_config};
use crate::sample::uniform_sampler::UniformBBoxSampler;
use crate::sheet::SheetProblem;
use anyhow::{Result, ensure};
use itertools::Itertools;
use jagua_rs::entities::Item;
use jagua_rs::geometry::geo_enums::RotationRange;
use jagua_rs::geometry::geo_traits::Transformable;
use jagua_rs::geometry::primitives::Rect;
use jagua_rs::geometry::{DTransformation, Transformation};
use jagua_rs::probs::spp::entities::SPPlacement;
use log::{debug, info};
use ordered_float::OrderedFloat;
use rand::Rng;
use rand::rngs::Xoshiro256PlusPlus;
use std::cmp::Reverse;
use std::iter;
use std::time::Duration;

#[derive(Clone, Copy, Debug)]
pub struct GreedyConfig {
    /// Uniform samples per attempt on one sheet (on top of the deterministic corner candidates).
    pub n_samples: usize,
    /// Number of best samples refined by coordinate descent.
    pub n_coord_descents: usize,
    /// A sheet that rejects an item smaller than this fraction of its usable area is closed.
    pub close_ratio: f32,
    /// A sheet is skipped for an item at least this fraction as large as one it already rejected.
    pub reject_ratio: f32,
    /// A sheet is skipped when its free area is below this multiple of the item's area.
    pub free_slack: f32,
}

pub const DEFAULT_GREEDY_CONFIG: GreedyConfig = GreedyConfig {
    n_samples: 100,
    n_coord_descents: 3,
    close_ratio: 0.02,
    reject_ratio: 0.9,
    free_slack: 1.15,
};

#[derive(Clone, Copy, Debug, Default)]
pub struct GreedyStats {
    pub n_sheets: usize,
    pub n_attempts: usize,
    pub n_evals: usize,
    /// Corner candidates evaluated / found collision-free (diagnostic: are the tight fits reachable?).
    pub n_corner: usize,
    pub n_corner_clear: usize,
    /// Items whose final placement came from a corner candidate rather than a random sample.
    pub n_placed_by_corner: usize,
    pub elapsed: Duration,
}

/// Result of one sheet attempt.
struct Attempt {
    dt: Option<DTransformation>,
    from_corner: bool,
    n_evals: usize,
    n_corner: usize,
    n_corner_clear: usize,
}

/// Builds a complete initial placement sheet by sheet. `prob` must be empty.
///
/// For an unbounded sheet (`width: null`) the sheet is the whole strip and this degenerates to a
/// left-bottom fill with sheet-restricted sampling (one "sheet" = the current strip).
pub fn construct_greedy(mut prob: SheetProblem, mut rng: Xoshiro256PlusPlus, cfg: GreedyConfig) -> Result<(SheetProblem, GreedyStats)> {
    ensure!(prob.layout().is_empty(), "greedy constructor needs an empty problem");
    let start = jagua_rs::Instant::now();
    let spec = *prob.spec();
    let usable_area = spec.usable_width().unwrap_or(f32::INFINITY) * spec.usable_height();

    // Item instances by decreasing collision-shape area (then diameter), demand expanded.
    let order = (0..prob.items().len())
        .sorted_by_cached_key(|&idx| {
            let s = prob.item(idx).shape_cd();
            Reverse((OrderedFloat(s.area()), OrderedFloat(s.diameter())))
        })
        .flat_map(|idx| iter::repeat_n(idx, prob.item_demand_qtys()[idx]))
        .collect_vec();
    debug!("[GREEDY] placing items in order: {:?}", order);

    let mut free: Vec<f32> = vec![];
    let mut closed: Vec<bool> = vec![];
    let mut reject_area: Vec<f32> = vec![];
    let mut stats = GreedyStats::default();

    fn open_sheet(prob: &mut SheetProblem, free: &mut Vec<f32>, closed: &mut Vec<bool>, reject: &mut Vec<f32>, usable_area: f32) -> Result<usize> {
        free.push(usable_area);
        closed.push(false);
        reject.push(f32::INFINITY);
        let n = free.len();
        if prob.spec().width.is_some() {
            prob.change_strip_width(prob.width_for_sheets(n))?;
        }
        Ok(n - 1)
    }
    open_sheet(&mut prob, &mut free, &mut closed, &mut reject_area, usable_area)?;

    for item_idx in order {
        let item = prob.item(item_idx).clone();
        let area = item.shape_cd().area();
        let mut placement = None;
        let mut attempts = 0;
        // First fit over ALL open sheets (capping the attempts made items open new sheets while
        // later sheets still had room); the filters keep the cost down.
        for j in 0..free.len() {
            if closed[j] || free[j] < cfg.free_slack * area || area >= cfg.reject_ratio * reject_area[j] {
                continue;
            }
            attempts += 1;
            let a = try_sheet(&prob, &item, j, cfg.n_samples, cfg.n_coord_descents, &mut rng);
            stats.n_evals += a.n_evals;
            stats.n_corner += a.n_corner;
            stats.n_corner_clear += a.n_corner_clear;
            match a.dt {
                Some(dt) => {
                    stats.n_placed_by_corner += a.from_corner as usize;
                    placement = Some((j, dt));
                    break;
                }
                None => {
                    reject_area[j] = reject_area[j].min(area);
                    if area < cfg.close_ratio * usable_area {
                        closed[j] = true;
                    }
                }
            }
        }
        stats.n_attempts += attempts;

        if placement.is_none() {
            // No open sheet takes the item: open fresh sheets (more samples, the sheet is empty).
            let first_new = free.len();
            while placement.is_none() {
                let j = open_sheet(&mut prob, &mut free, &mut closed, &mut reject_area, usable_area)?;
                let a = try_sheet(&prob, &item, j, 4 * cfg.n_samples, cfg.n_coord_descents, &mut rng);
                stats.n_evals += a.n_evals;
                stats.n_corner += a.n_corner;
                stats.n_corner_clear += a.n_corner_clear;
                stats.n_attempts += 1;
                match a.dt {
                    Some(dt) => {
                        stats.n_placed_by_corner += a.from_corner as usize;
                        placement = Some((j, dt));
                    }
                    None if free.len() - first_new >= 3 => {
                        return Err(ConstructionError { external_id: item.external_id() }.into());
                    }
                    None => {}
                }
            }
        }

        let (j, dt) = placement.unwrap();
        free[j] -= area;
        prob.place_item(SPPlacement { item_idx, d_transf: dt });
        debug!("[GREEDY] item {}/{} (idx {}) on sheet {} at [{}]", prob.n_placed_items(), prob.total_item_qty(), item_idx, j, dt);
    }

    prob.fit_strip()?;
    stats.n_sheets = prob.geometry().n_sheets;
    stats.elapsed = start.elapsed();
    info!("[GREEDY] placed {} items on {} sheets in {:?} ({} attempts, {} evals; corner candidates {}/{} clear, {} items placed by corner), width {:.3} ({:.3}%)",
        prob.n_placed_items(), stats.n_sheets, stats.elapsed, stats.n_attempts, stats.n_evals,
        stats.n_corner_clear, stats.n_corner, stats.n_placed_by_corner, prob.strip_width(), prob.density() * 100.0);
    Ok((prob, stats))
}

/// Left-bottom search for `item` restricted to the usable region of sheet `j`.
fn try_sheet(prob: &SheetProblem, item: &Item, j: usize, n_samples: usize, n_cd: usize, rng: &mut impl Rng) -> Attempt {
    let none = Attempt { dt: None, from_corner: false, n_evals: 0, n_corner: 0, n_corner_clear: 0 };
    let spec = prob.spec();
    let half = prob.separation() / 2.0;
    // Collision shapes are inflated by sep/2, so the region they may occupy is the usable region
    // grown by sep/2 (consistent with the container outline handed to jagua-rs).
    let x_max = spec.usable_x_max(j).unwrap_or(prob.strip_width());
    let region = match Rect::try_new(spec.usable_x_min(j) - half, spec.margin - half, x_max + half, spec.height - spec.margin + half) {
        Ok(r) => r,
        Err(_) => return none,
    };
    let huge = Rect::try_new(-1e9, -1e9, 1e9, 1e9).unwrap();
    let Some(sampler) = UniformBBoxSampler::new(huge, item, region) else {
        return none;
    };

    let layout = prob.layout();
    let mut evaluator = LBFEvaluator::new(layout, item);
    let item_min_dim = f32::min(item.shape_cd().bbox().width(), item.shape_cd().bbox().height());
    let mut best = BestSamples::new(n_cd, item_min_dim * UNIQUE_SAMPLE_THRESHOLD);
    // Deterministic candidates flush against the sheet corner or a placed item first: random
    // samples rarely hit a pocket that fits the item tightly, these do.
    let corners = corner_candidates(prob, item, j, region);
    let (n_corner, mut n_corner_clear) = (corners.len(), 0);
    let mut best_corner: Option<(DTransformation, SampleEval)> = None;
    for dt in corners {
        let eval = evaluator.evaluate_sample(dt, Some(best.upper_bound()));
        if matches!(eval, SampleEval::Clear { .. }) {
            n_corner_clear += 1;
            if best_corner.is_none_or(|(_, e)| eval < e) {
                best_corner = Some((dt, eval));
            }
        }
        best.report(dt, eval);
    }
    for _ in 0..n_samples {
        let dt = sampler.sample(rng);
        let eval = evaluator.evaluate_sample(dt, Some(best.upper_bound()));
        best.report(dt, eval);
    }
    for start in best.samples.clone() {
        let descended = refine_coord_desc(start, &mut evaluator, prerefine_cd_config(item), rng);
        best.report(descended.0, descended.1);
    }
    let final_sample = best.best().map(|s| refine_coord_desc(s, &mut evaluator, final_refine_cd_config(item), rng));
    let dt = match final_sample {
        Some((dt, SampleEval::Clear { .. })) => Some(dt),
        _ => None,
    };
    // "From corner" when the chosen placement is not (noticeably) better than the best corner
    // candidate: coordinate descent cannot improve a flush position much.
    let from_corner = match (final_sample, best_corner) {
        (Some((_, SampleEval::Clear { loss: f })), Some((_, SampleEval::Clear { loss: c }))) => f >= c - 1e-3 * c.abs().max(1.0),
        _ => false,
    };
    Attempt { dt, from_corner, n_evals: evaluator.n_evals(), n_corner, n_corner_clear }
}

/// Translations that put the item's rotated collision bbox flush (plus a rounding gap) against the
/// bottom-left corner of `region` or against a placed item of sheet `j`: right of it bottom-aligned,
/// above it left-aligned, on the left edge above it, on the bottom edge right of it. Classic
/// bottom-left candidate points for rectangles; for other shapes they are still valid positions,
/// just not necessarily tight.
fn corner_candidates(prob: &SheetProblem, item: &Item, j: usize, region: Rect) -> Vec<DTransformation> {
    let spec = prob.spec();
    let rotations: Vec<f32> = match item.allowed_orientations().rotations() {
        RotationRange::None => vec![0.0],
        RotationRange::Discrete(r) => r.clone(),
        RotationRange::Continuous => (0..4).map(|i| i as f32 * std::f32::consts::FRAC_PI_2).collect(),
    };
    // Touching edges count as collisions: leave a gap above the f32 resolution at this x.
    let eps = (region.x_max.abs() * 4.0 * f32::EPSILON).max(0.01);
    let placed: Vec<Rect> = prob
        .layout()
        .placed_items()
        .values()
        .map(|pi| pi.shape().bbox())
        .filter(|b| spec.sheet_index_of(0.5 * (b.x_min + b.x_max)) == j)
        .collect();

    let mut candidates = Vec::with_capacity(rotations.len() * (4 * placed.len() + 1));
    for r in rotations {
        let bb = item.shape_cd().transform_clone(&Transformation::from_rotation(r)).bbox();
        if bb.width() > region.width() || bb.height() > region.height() {
            continue;
        }
        let targets = iter::once((region.x_min + eps, region.y_min + eps)).chain(placed.iter().flat_map(|p| {
            [
                (p.x_max + eps, p.y_min),
                (p.x_min, p.y_max + eps),
                (region.x_min + eps, p.y_max + eps),
                (p.x_max + eps, region.y_min + eps),
            ]
        }));
        for (tx, ty) in targets {
            if tx + bb.width() > region.x_max - eps || ty + bb.height() > region.y_max - eps {
                continue;
            }
            candidates.push(DTransformation::new(r, (tx - bb.x_min, ty - bb.y_min)));
        }
    }
    candidates
}
