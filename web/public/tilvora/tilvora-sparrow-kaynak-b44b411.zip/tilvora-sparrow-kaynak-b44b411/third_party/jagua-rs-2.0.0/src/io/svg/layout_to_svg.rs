use crate::collision_detection::hazards::BasicHazardEntity;
use crate::collision_detection::hazards::collector::BasicHazardCollector;
use crate::collision_detection::hazards::filter::NoFilter;
use crate::entities::{Layout, LayoutSnapshot};
use crate::geometry::geo_traits::Transformable;
use crate::geometry::primitives::{Circle, Edge, Rect};
use crate::geometry::{DTransformation, Transformation};
use crate::io::export::int_to_ext_transformation;
use crate::io::svg::svg_util;
use crate::io::svg::svg_util::SvgDrawOptions;
use std::hash::{DefaultHasher, Hash, Hasher};
use svg::Document;
use svg::node::element::{Definitions, Group, Text, Title, Use};

/// Render a snapshot using its shared item definitions.
/// See [`layout_to_svg_group`] for `container_id`.
#[must_use]
pub fn s_layout_to_svg(
    s_layout: &LayoutSnapshot,
    container_id: u64,
    options: SvgDrawOptions,
    title: &str,
) -> Document {
    let layout = Layout::from_snapshot(s_layout);
    layout_to_svg(&layout, container_id, options, title)
}

/// Render a layout using its shared item definitions.
/// See [`layout_to_svg_group`] for `container_id`.
#[must_use]
pub fn layout_to_svg(
    layout: &Layout,
    container_id: u64,
    options: SvgDrawOptions,
    title: &str,
) -> Document {
    let (group, bbox) = layout_to_svg_group(layout, container_id, options, title);

    let vbox = bbox.scale(1.1);
    let vbox_svg = format!(
        "{} {} {} {}",
        vbox.x_min,
        vbox.y_min,
        vbox.width(),
        vbox.height()
    );

    Document::new().set("viewBox", vbox_svg).add(group)
}

#[allow(clippy::too_many_lines)]
/// Render only the item definitions used by this layout.
///
/// `container_id` is the caller's external bin or sheet ID, as in
/// [`export_layout_snapshot`](crate::io::export::export_layout_snapshot). It names the
/// `container_{id}` group and prefixes item definition IDs, so several layouts can share
/// one document.
pub fn layout_to_svg_group(
    layout: &Layout,
    container_id: u64,
    options: SvgDrawOptions,
    title: &str,
) -> (Group, Rect) {
    let container = &layout.container;

    let bbox = container
        .outer_orig
        .bbox()
        .resize_by(
            container.outer_orig.bbox().height() * 0.01,
            container.outer_orig.bbox().height() * 0.01,
        )
        .unwrap();

    let theme = &options.theme;

    let stroke_width =
        f32::min(bbox.width(), bbox.height()) * 0.001 * theme.stroke_width_multiplier;

    let label = {
        //print some information on above the left top of the container
        let bbox = container.outer_orig.bbox();

        let label_content = format!(
            "h: {:.3} | w: {:.3} | d: {:.3}% | {}",
            bbox.height(),
            bbox.width(),
            layout.density() * 100.0,
            title,
        );
        Text::new(label_content)
            .set("x", bbox.x_min)
            .set(
                "y",
                bbox.y_min - 0.5 * 0.025 * f32::min(bbox.width(), bbox.height()),
            )
            .set("font-size", f32::min(bbox.width(), bbox.height()) * 0.025)
            .set("font-family", "monospace")
            .set("font-weight", "500")
    };

    let highlight_cd_shape_style = &[
        ("fill", "none"),
        ("stroke-width", &*format!("{}", 0.5 * stroke_width)),
        ("stroke", "black"),
        ("stroke-opacity", "0.3"),
        (
            "stroke-dasharray",
            &*format!("{} {}", 1.0 * stroke_width, 2.0 * stroke_width),
        ),
        ("stroke-linecap", "round"),
        ("stroke-linejoin", "round"),
    ];

    //draw container
    let container_group = {
        let container_group = Group::new().set("id", format!("container_{container_id}"));
        let bbox = container.outer_orig.bbox();
        let title = Title::new(format!(
            "container, bbox: [x_min: {:.3}, y_min: {:.3}, x_max: {:.3}, y_max: {:.3}]",
            bbox.x_min, bbox.y_min, bbox.x_max, bbox.y_max
        ));

        //outer
        container_group
            .add(svg_util::data_to_path(
                svg_util::original_shape_data(
                    &container.outer_orig,
                    &container.outer_cd,
                    options.draw_cd_shapes,
                ),
                &[
                    ("fill", &*format!("{}", theme.container_fill)),
                    ("stroke", "black"),
                    ("stroke-width", &*format!("{}", 2.0 * stroke_width)),
                ],
            ))
            .add(title)
    };

    let quality_zones_group = {
        let mut qz_group = Group::new().set("id", "quality_zones");

        //quality zones
        for qz in container.quality_zones.iter().rev().flatten() {
            let color = theme.qz_fill[qz.quality];
            let stroke_color = svg_util::change_brightness(color, 0.5);
            for (orig_qz_shape, intern_qz_shape) in qz.shapes_orig.iter().zip(qz.shapes_cd.iter()) {
                qz_group = qz_group.add(
                    svg_util::data_to_path(
                        svg_util::original_shape_data(
                            orig_qz_shape,
                            intern_qz_shape,
                            options.draw_cd_shapes,
                        ),
                        &[
                            ("fill", &*format!("{color}")),
                            ("fill-opacity", "0.50"),
                            ("stroke", &*format!("{stroke_color}")),
                            ("stroke-width", &*format!("{}", 2.0 * stroke_width)),
                            ("stroke-opacity", &*format!("{}", theme.qz_stroke_opac)),
                            ("stroke-dasharray", &*format!("{}", 5.0 * stroke_width)),
                            ("stroke-linecap", "round"),
                            ("stroke-linejoin", "round"),
                        ],
                    )
                    .add(Title::new(format!("quality zone, q: {}", qz.quality))),
                );
            }
        }
        qz_group
    };

    //draw items
    let (items_group, surrogate_group, mut highlight_cd_shape_group) = {
        //define all the items and their surrogates (if enabled)
        let mut item_defs = Definitions::new();
        let mut surrogate_defs = Definitions::new();
        for item in layout.items() {
            let color = match item.min_quality {
                None => theme.item_fill,
                Some(q) => svg_util::blend_colors(theme.item_fill, theme.qz_fill[q]),
            };
            let external_id = item.external_id;
            item_defs = item_defs.add(
                Group::new()
                    .set("id", format!("item_{container_id}_{external_id}"))
                    .add(svg_util::data_to_path(
                        svg_util::original_shape_data(
                            &item.shape_orig,
                            &item.shape_cd,
                            options.draw_cd_shapes,
                        ),
                        &[
                            ("fill", &*format!("{color}")),
                            ("stroke-width", &*format!("{stroke_width}")),
                            ("fill-rule", "nonzero"),
                            ("stroke", "black"),
                            ("fill-opacity", "0.5"),
                        ],
                    )),
            );

            let int_transf = if options.draw_cd_shapes {
                Transformation::empty()
            } else {
                // The original shape is drawn on the SVG, we need to inverse the pre-transform
                let pre_transform = item.shape_orig.pre_transform.compose();
                pre_transform.inverse()
            };

            if options.surrogate {
                let mut surrogate_group =
                    Group::new().set("id", format!("surrogate_{container_id}_{external_id}"));
                let poi_style = [
                    ("fill", "black"),
                    ("fill-opacity", "0.1"),
                    ("stroke", "black"),
                    ("stroke-width", &*format!("{stroke_width}")),
                    ("stroke-opacity", "0.8"),
                ];
                let ff_style = [
                    ("fill", "none"),
                    ("stroke", "black"),
                    ("stroke-width", &*format!("{stroke_width}")),
                    ("stroke-opacity", "0.8"),
                ];
                let no_ff_style = [
                    ("fill", "none"),
                    ("stroke", "black"),
                    ("stroke-width", &*format!("{stroke_width}")),
                    ("stroke-opacity", "0.5"),
                    ("stroke-dasharray", &*format!("{}", 5.0 * stroke_width)),
                    ("stroke-linecap", "round"),
                    ("stroke-linejoin", "round"),
                ];

                let surrogate = item.shape_cd.surrogate();
                let poi = &surrogate.poles[0];
                let ff_poles = surrogate.ff_poles();

                for pole in &surrogate.poles {
                    if pole == poi {
                        let svg_circle =
                            svg_util::circle(pole.transform_clone(&int_transf), &poi_style);
                        surrogate_group = surrogate_group.add(svg_circle);
                    } else if ff_poles.contains(pole) {
                        let svg_circle =
                            svg_util::circle(pole.transform_clone(&int_transf), &ff_style);
                        surrogate_group = surrogate_group.add(svg_circle);
                    } else {
                        let svg_circle =
                            svg_util::circle(pole.transform_clone(&int_transf), &no_ff_style);
                        surrogate_group = surrogate_group.add(svg_circle);
                    }
                }
                surrogate_defs = surrogate_defs.add(surrogate_group);
            }

            if options.highlight_cd_shapes {
                let t_shape_cd = item.shape_cd.transform_clone(&int_transf);
                //draw the CD shape with a dotted line, and no fill
                let mut group = Group::new().add(svg_util::data_to_path(
                    svg_util::simple_polygon_data(&t_shape_cd),
                    highlight_cd_shape_style,
                ));
                if options.draw_cd_shapes {
                    //draw all the vertices as dots
                    for p in &t_shape_cd.vertices {
                        let circle = Circle {
                            center: *p,
                            radius: 0.5 * stroke_width,
                        };
                        group = group.add(svg_util::circle(
                            circle,
                            &[("fill", "cyan"), ("fill-opacity", "0.8")],
                        ));
                    }
                }
                let group = group.set("id", format!("cd_shape_{container_id}_{external_id}"));
                item_defs = item_defs.add(group);
            }
        }
        let mut items_group = Group::new().set("id", "items").add(item_defs);
        let mut surrogate_group = Group::new().set("id", "surrogates").add(surrogate_defs);
        let mut highlight_cd_shapes_group = Group::new().set("id", "highlight_cd_shapes");

        for pi in layout.placed_items.values() {
            let item = &pi.item;
            let external_id = item.external_id;
            let dtransf = if options.draw_cd_shapes {
                pi.d_transf
            } else {
                int_to_ext_transformation(&pi.d_transf, &item.shape_orig.pre_transform)
            };
            let title = Title::new(format!("item, id: {external_id}, transf: [{dtransf}]"));
            let pi_ref = Use::new()
                .set("transform", transform_to_svg(dtransf))
                .set("href", format!("#item_{container_id}_{external_id}"))
                .add(title);

            items_group = items_group.add(pi_ref);

            if options.surrogate {
                let pi_surr_ref = Use::new()
                    .set("transform", transform_to_svg(dtransf))
                    .set("href", format!("#surrogate_{container_id}_{external_id}"));

                surrogate_group = surrogate_group.add(pi_surr_ref);
            }
            if options.highlight_cd_shapes {
                let pi_cd_ref = Use::new()
                    .set("transform", transform_to_svg(dtransf))
                    .set("href", format!("#cd_shape_{container_id}_{external_id}"));
                highlight_cd_shapes_group = highlight_cd_shapes_group.add(pi_cd_ref);
            }
        }

        (items_group, surrogate_group, highlight_cd_shapes_group)
    };

    //highlight colliding items (if enabled)
    let collision_group = if options.highlight_collisions {
        let mut collision_group = Group::new().set("id", "collision_lines");
        for (pk, pi) in &layout.placed_items {
            let collector = {
                let mut collector =
                    BasicHazardCollector::with_capacity(layout.cde().hazards_map.len());
                layout
                    .cde()
                    .collect_poly_collisions(&pi.shape, &NoFilter, &mut collector);
                collector.retain(|_, entity| {
                    // filter out the item itself
                    if let BasicHazardEntity::PlacedItem {
                        pk: colliding_pk, ..
                    } = entity
                    {
                        *colliding_pk != pk
                    } else {
                        true
                    }
                });
                collector
            };
            for (_, haz_entity) in &collector {
                match haz_entity {
                    BasicHazardEntity::PlacedItem {
                        pk: colliding_pk, ..
                    } => {
                        let haz_hash = {
                            let mut hasher = DefaultHasher::new();
                            haz_entity.hash(&mut hasher);
                            hasher.finish()
                        };
                        let pi_hash = {
                            let mut hasher = DefaultHasher::new();
                            BasicHazardEntity::from((pk, pi)).hash(&mut hasher);
                            hasher.finish()
                        };

                        if haz_hash < pi_hash {
                            // avoid duplicate lines
                            let start = pi.shape.poi.center;
                            let end = layout.placed_items[*colliding_pk].shape.poi.center;
                            collision_group = collision_group.add(svg_util::data_to_path(
                                svg_util::edge_data(Edge { start, end }),
                                &[
                                    ("stroke", &*format!("{}", theme.collision_highlight_color)),
                                    ("stroke-opacity", "0.75"),
                                    ("stroke-width", &*format!("{}", stroke_width * 4.0)),
                                    (
                                        "stroke-dasharray",
                                        &*format!("{} {}", 4.0 * stroke_width, 8.0 * stroke_width),
                                    ),
                                    ("stroke-linecap", "round"),
                                    ("stroke-linejoin", "round"),
                                ],
                            ));
                        }
                    }
                    BasicHazardEntity::Hole { idx }
                    | BasicHazardEntity::InferiorQualityZone { idx, .. } => {
                        let quality =
                            if let BasicHazardEntity::InferiorQualityZone { quality, .. } =
                                haz_entity
                            {
                                if pi
                                    .item
                                    .min_quality
                                    .is_some_and(|required| *quality >= required)
                                {
                                    continue;
                                }
                                *quality
                            } else {
                                0
                            };
                        let start = pi.shape.poi.center;
                        let end = container.quality_zones[quality].as_ref().unwrap().shapes_cd
                            [*idx]
                            .poi
                            .center;
                        collision_group = collision_group.add(svg_util::data_to_path(
                            svg_util::edge_data(Edge { start, end }),
                            &[
                                ("stroke", &*format!("{}", theme.collision_highlight_color)),
                                ("stroke-opacity", "0.75"),
                                ("stroke-width", &*format!("{}", stroke_width * 4.0)),
                                (
                                    "stroke-dasharray",
                                    &*format!("{} {}", 4.0 * stroke_width, 8.0 * stroke_width),
                                ),
                                ("stroke-linecap", "round"),
                                ("stroke-linejoin", "round"),
                            ],
                        ));
                    }
                    BasicHazardEntity::Exterior => {
                        collision_group = collision_group.add(svg_util::point(
                            pi.shape.poi.center,
                            Some(&*format!("{}", theme.collision_highlight_color)),
                            Some(3.0 * stroke_width),
                        ));
                    }
                }
            }
        }
        Some(collision_group)
    } else {
        None
    };

    if options.highlight_cd_shapes {
        highlight_cd_shape_group = highlight_cd_shape_group.add(svg_util::data_to_path(
            svg_util::simple_polygon_data(&container.outer_cd),
            highlight_cd_shape_style,
        ));
    }

    let optionals = [
        Some(highlight_cd_shape_group),
        Some(surrogate_group),
        collision_group,
    ]
    .into_iter()
    .flatten()
    .fold(Group::new().set("id", "optionals"), Group::add);

    let combined_group = Group::new()
        .add(container_group)
        .add(items_group)
        .add(quality_zones_group)
        .add(optionals)
        .add(label);

    (combined_group, bbox)
}
fn transform_to_svg(dt: DTransformation) -> String {
    //https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/transform
    //operations are effectively applied from right to left
    let (tx, ty) = dt.translation();
    let r = dt.rotation().to_degrees();
    let reflection = if dt.reflected { ", scale(1 -1)" } else { "" };
    format!("translate({tx} {ty}), rotate({r}){reflection}")
}
