extern crate core;

mod ctrlc_terminator;
mod logger;

use clap::Parser as Clap;
use jagua_rs::io::import::Importer;
use log::{info, warn, Level};
use rand::{Rng, SeedableRng};
use sparrow::config::*;
use sparrow::optimizer::optimize;
use sparrow::optimizer::problem::StripLike;
use sparrow::sheet::SplitMode;
use sparrow::sheet::compress::{optimize_sheets, SheetCompression};
use sparrow::sheet::greedy::{construct_greedy, DEFAULT_GREEDY_CONFIG};
use sparrow::sheet::io::ExtSheetOutput;
use sparrow::util::io;
use sparrow::util::io::{ExtSPOutput, InputKind};
use crate::args::MainCli;
use sparrow::EPOCH;
use std::fs;
use std::path::Path;
use std::time::Duration;

use anyhow::{bail, Result};
use rand::rngs::Xoshiro256PlusPlus;
use sparrow::consts::{DEFAULT_COMPRESS_TIME_RATIO, DEFAULT_EXPLORE_TIME_RATIO, DEFAULT_FAIL_DECAY_RATIO_CMPR, DEFAULT_MAX_CONSEQ_FAILS_EXPL, LOG_LEVEL_FILTER_DEBUG, LOG_LEVEL_FILTER_RELEASE};
use ctrlc_terminator::CtrlCTerminator;
use sparrow::util::svg_exporter::SvgExporter;

pub const OUTPUT_DIR: &str = "output";

pub const LIVE_DIR: &str = "data/live";

/// Process exit code when the solution needs more sheets than `sheet.count` allows (output is still written).
pub const EXIT_SHEET_LIMIT_EXCEEDED: i32 = 3;

pub fn run() -> Result<()>{
    let mut config = DEFAULT_SPARROW_CONFIG;

    let args = MainCli::parse();
    let output_dir = args.output_dir.clone().unwrap_or_else(|| OUTPUT_DIR.to_string());

    fs::create_dir_all(&output_dir)?;
    let log_file_path = format!("{}/log.txt", output_dir);
    match cfg!(debug_assertions) {
        true => logger::init_logger(LOG_LEVEL_FILTER_DEBUG, Path::new(&log_file_path))?,
        false => logger::init_logger(LOG_LEVEL_FILTER_RELEASE, Path::new(&log_file_path))?,
    }

    let input_file_path = &args.input;
    let (explore_dur, compress_dur) = match (args.global_time, args.exploration, args.compression) {
        (Some(gt), None, None) => {
            (Duration::from_secs(gt).mul_f32(DEFAULT_EXPLORE_TIME_RATIO), Duration::from_secs(gt).mul_f32(DEFAULT_COMPRESS_TIME_RATIO))
        },
        (None, Some(et), Some(ct)) => {
            (Duration::from_secs(et), Duration::from_secs(ct))
        },
        (None, None, None) => {
            warn!("[MAIN] no time limit specified");
            (Duration::from_secs(600).mul_f32(DEFAULT_EXPLORE_TIME_RATIO), Duration::from_secs(600).mul_f32(DEFAULT_COMPRESS_TIME_RATIO))
        },
        _ => bail!("invalid cli pattern (clap should have caught this)"),
    };
    config.expl_cfg.time_limit = explore_dur;
    config.cmpr_cfg.time_limit = compress_dur;
    if args.early_termination {
        config.expl_cfg.max_conseq_failed_attempts = Some(DEFAULT_MAX_CONSEQ_FAILS_EXPL);
        config.cmpr_cfg.shrink_decay = ShrinkDecayStrategy::FailureBased(DEFAULT_FAIL_DECAY_RATIO_CMPR);
        warn!("[MAIN] early termination enabled!");
    }
    args.apply_config_overrides(&mut config);

    info!("[MAIN] configured to explore for {}s and compress for {}s", explore_dur.as_secs(), compress_dur.as_secs());

    let rng = match config.rng_seed {
        Some(seed) => {
            info!("[MAIN] using seed: {}", seed);
            Xoshiro256PlusPlus::seed_from_u64(seed as u64)
        },
        None => {
            let seed = rand::random();
            warn!("[MAIN] no seed provided, using: {}", seed);
            Xoshiro256PlusPlus::seed_from_u64(seed)
        }
    };

    info!("[MAIN] system time: {}", jiff::Timestamp::now());

    let input = io::read_input(Path::new(&input_file_path))?;
    let importer = Importer::new(config.cde_config, config.poly_simpl_tolerance, config.narrow_concavity_cutoff_ratio);

    let instance_name = match &input {
        InputKind::Strip(ext_instance, _) => ext_instance.name.clone(),
        InputKind::Sheet(ext_instance) => ext_instance.name.clone(),
    };

    let mut svg_exporter = {
        let final_svg_path = Some(format!("{output_dir}/final_{instance_name}.svg"));

        let intermediate_svg_dir = match cfg!(feature = "only_final_svg") {
            true => None,
            false => Some(format!("{output_dir}/sols_{instance_name}"))
        };

        let live_svg_path = match cfg!(feature = "live_svg") {
            true => Some(format!("{LIVE_DIR}/.live_solution.svg")),
            false => None
        };

        SvgExporter::new(
            final_svg_path,
            intermediate_svg_dir,
            live_svg_path
        )
    };

    let mut ctrlc_terminator = CtrlCTerminator::new();
    let json_path = format!("{output_dir}/final_{instance_name}.json");

    match input {
        InputKind::Strip(ext_instance, ext_solution) => {
            let instance = jagua_rs::probs::spp::io::import_instance(&importer, &ext_instance)?;

            let initial_solution = ext_solution.map(|e|
                jagua_rs::probs::spp::io::import_solution(&instance, &e)
            ).transpose()?;

            info!("[MAIN] loaded instance {} with #{} items", ext_instance.name, instance.total_item_qty());

            let solution = optimize(
                instance,
                rng,
                &mut svg_exporter,
                &mut ctrlc_terminator,
                &config.expl_cfg,
                &config.cmpr_cfg,
                initial_solution.as_ref()
            )?;

            let json_output = ExtSPOutput {
                instance: ext_instance,
                solution: jagua_rs::probs::spp::io::export(&solution, *EPOCH)
            };
            io::write_json(&json_output, Path::new(json_path.as_str()), Level::Info)?;
        }
        InputKind::Sheet(ext_instance) => {
            let split_mode: SplitMode = args.sheet_split.parse().map_err(anyhow::Error::msg)?;
            let prob = sparrow::sheet::io::import_instance(&importer, &ext_instance)?
                .with_split_mode(split_mode)
                .with_step_ratio(args.sheet_step);
            info!("[MAIN] loaded multi-sheet instance {} with #{} items, sheet {:?}, separation {}, split {:?}, step ratio {:?}, init {}",
                ext_instance.name, prob.total_item_qty(), prob.spec(), prob.separation(), split_mode, args.sheet_step, args.init);

            let mut rng = rng;
            let (prob, initial_solution) = match args.init.as_str() {
                "lbf" => (prob, None),
                "greedy" => {
                    let mut greedy_cfg = DEFAULT_GREEDY_CONFIG;
                    if let Some(n) = args.greedy_samples {
                        greedy_cfg.n_samples = n;
                    }
                    let greedy_rng = Xoshiro256PlusPlus::seed_from_u64(rng.next_u64());
                    let (built, stats) = construct_greedy(prob, greedy_rng, greedy_cfg)?;
                    info!("[MAIN] greedy start: {} sheets in {:.3}s", stats.n_sheets, stats.elapsed.as_secs_f64());
                    let sol = built.save();
                    (built, Some(sol))
                }
                other => bail!("unknown --init '{other}' (greedy | lbf)"),
            };

            let compression: SheetCompression = args.sheet_compress.parse().map_err(anyhow::Error::msg)?;
            let solution = optimize_sheets(
                prob,
                rng,
                &mut svg_exporter,
                &mut ctrlc_terminator,
                &config.expl_cfg,
                &config.cmpr_cfg,
                initial_solution.as_ref(),
                compression,
            )?;

            let ext_solution = sparrow::sheet::io::export(&solution, *EPOCH);
            info!("[MAIN] sheets: {} | last sheet used width: {:.3} | density: {:.3}% (usable {:.3}%)",
                ext_solution.sheet_count, ext_solution.last_sheet_used_width,
                ext_solution.density * 100.0, ext_solution.usable_density * 100.0);
            let limit_exceeded = ext_solution.sheet_limit_exceeded;
            let json_output = ExtSheetOutput {
                instance: ext_instance,
                solution: ext_solution,
            };
            io::write_json(&json_output, Path::new(json_path.as_str()), Level::Info)?;
            if limit_exceeded {
                warn!("[MAIN] sheet limit exceeded: solution needs {} sheets", json_output.solution.sheet_count);
                std::process::exit(EXIT_SHEET_LIMIT_EXCEEDED);
            }
        }
    }

    Ok(())
}
