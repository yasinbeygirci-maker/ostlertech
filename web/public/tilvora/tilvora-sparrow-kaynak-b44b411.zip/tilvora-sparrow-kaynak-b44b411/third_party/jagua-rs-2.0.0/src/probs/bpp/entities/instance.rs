use crate::entities::Item;
use crate::probs::bpp::entities::bin::Bin;
use crate::probs::bpp::util::assertions::instance_item_bin_ids_correct;
use itertools::Itertools;
use std::sync::Arc;

#[derive(Debug, Clone)]
/// Instance of the Bin Packing Problem.
pub struct BPInstance {
    /// The items to be packed and their demands
    pub items: Vec<(Arc<Item>, usize)>,
    /// Set of bins available to pack the items
    pub bins: Vec<Bin>,
}

impl BPInstance {
    #[must_use]
    pub fn new(items: Vec<(Arc<Item>, usize)>, bins: Vec<Bin>) -> Self {
        assert!(instance_item_bin_ids_correct(&items, &bins));

        assert!(items.iter().map(|(item, _)| item.external_id).all_unique());
        Self { items, bins }
    }

    #[allow(clippy::cast_precision_loss)]
    #[must_use]
    pub fn item_area(&self) -> f32 {
        self.items
            .iter()
            .map(|(item, qty)| item.shape_orig.area() * *qty as f32)
            .sum()
    }

    #[must_use]
    pub fn item_qty(&self, idx: usize) -> usize {
        self.items[idx].1
    }

    pub fn bins(&self) -> impl Iterator<Item = &Bin> {
        self.bins.iter()
    }

    #[must_use]
    pub fn bin_qty(&self, id: usize) -> usize {
        self.bins[id].stock
    }

    #[must_use]
    pub fn total_item_qty(&self) -> usize {
        self.items.iter().map(|(_, qty)| *qty).sum()
    }

    /// Retrieve an item by its internal index.
    #[must_use]
    pub fn item(&self, idx: usize) -> &Arc<Item> {
        &self.items[idx].0
    }

    /// Resolve an external item ID, returning None for unknown or zero-demand items.
    #[must_use]
    pub fn item_idx(&self, external_id: u64) -> Option<usize> {
        self.items
            .iter()
            .find(|(item, _)| item.external_id == external_id)
            .map(|(item, _)| item.idx)
    }
}
