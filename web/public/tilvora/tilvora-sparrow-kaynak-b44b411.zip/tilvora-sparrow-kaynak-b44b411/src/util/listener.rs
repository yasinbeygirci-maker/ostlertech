use crate::optimizer::problem::StripSolution;

/// Trait for listeners that can receive solutions during the optimization process.
/// Generic over the solution type so that both strip packing and multi-sheet solutions can be reported.
pub trait SolutionListener<S: StripSolution> {
    fn report(&mut self, report: ReportType, solution: &S);

    fn report_phase(&mut self, _phase: OptimizationPhase) {}

    fn report_separation_progress(&mut self, _progress: SeparationProgress) {}

    fn report_separation_result(&mut self, _result: SeparationResult) {}

    fn report_compression_progress(&mut self, _shrink_step: f32) {}
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OptimizationPhase {
    Exploration,
    Compression,
}

/// Progress within one call to [`crate::optimizer::separator::Separator::separate`].
/// Iteration zero describes the initial layout; later values describe completed iterations.
#[derive(Debug, Clone, Copy)]
pub struct SeparationProgress {
    pub strip_width: f32,
    pub density: f32,
    pub iteration: usize,
    pub min_loss: f32,
}

#[derive(Debug, Clone, Copy)]
pub struct SeparationResult {
    pub success: bool,
    pub elapsed_seconds: f32,
    pub total_evals: usize,
    pub total_moves: usize,
    pub iterations: usize,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ReportType {
    /// Report contains a feasible solution reached by the exploration phase.
    ExplFeas,
    /// Report contains an infeasible solution reached by the exploration phase.
    ExplInfeas,
    /// Report contains an intermediate solution from the exploration phase that is closer to feasibility than the previous one.
    ExplImproving,
    /// Report contains a feasible solution from the comparison phase.
    CmprFeas,
    /// Report contains the final solution
    Final,
}

/// A dummy implementation of the `SolutionListener` trait that does nothing.
pub struct DummySolListener;

impl<S: StripSolution> SolutionListener<S> for DummySolListener {
    fn report(&mut self, _report: ReportType, _solution: &S) {
        // Do nothing
    }
}
