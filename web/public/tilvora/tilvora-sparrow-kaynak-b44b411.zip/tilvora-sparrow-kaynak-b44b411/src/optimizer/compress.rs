use crate::config::{CompressionConfig, ShrinkDecayStrategy};
use crate::optimizer::problem::{StripLike, StripSolution};
use crate::optimizer::separator::Separator;
use crate::util::listener::{ReportType, SolutionListener};
use crate::util::terminator::Terminator;
use jagua_rs::Instant;
use log::info;
use rand::{Rng, RngExt};

/// Algorithm 13 from https://doi.org/10.48550/arXiv.2509.13329
pub fn compression_phase<P: StripLike>(
    sep: &mut Separator<P>,
    init_sol: &P::Solution,
    sol_listener: &mut impl SolutionListener<P::Solution>,
    term: &impl Terminator,
    config: &CompressionConfig
) -> P::Solution {
    let width_lower_bound = super::strip_width_lower_bound(&sep.prob);
    let mut best_sol = init_sol.clone();
    let start = Instant::now();
    let mut n_failed_attempts = 0;

    // Create the function to calculate the shrink step size.
    let shrink_step_size = |n_failed_attempts: i32| -> f32 {
        match config.shrink_decay {
            ShrinkDecayStrategy::TimeBased => {
                let range = config.shrink_range.1 - config.shrink_range.0;
                let elapsed = start.elapsed();
                let ratio = elapsed.as_secs_f32() / config.time_limit.as_secs_f32();
                config.shrink_range.0 + ratio * range
            }
            ShrinkDecayStrategy::FailureBased(r) => {
                config.shrink_range.0 * r.powi(n_failed_attempts)
            }
        }
    };

    // As long as the shrink step size is above the minimum, keep attempting to compress
    while !term.kill() && let step = shrink_step_size(n_failed_attempts) && step >= config.shrink_range.1 {
        let width = best_sol.strip_width();
        let next_width = width * (1.0 - step);
        if next_width < width_lower_bound || next_width >= width {
            info!("[CMPR] stopping at strip width lower bound: {:.3}", width_lower_bound);
            break;
        }
        sol_listener.report_compression_progress(step);
        match attempt_to_compress(sep, &best_sol, step, term, sol_listener) {
            Some(compacted_sol) => {
                info!("[CMPR] success at {:.3}% ({:.3} | {:.3}%)", step * 100.0, compacted_sol.strip_width(), compacted_sol.density() * 100.0);
                sol_listener.report(ReportType::CmprFeas, &compacted_sol);
                best_sol = compacted_sol;
            }
            None => {
                info!("[CMPR] failed at {:.3}%", step * 100.0);
                n_failed_attempts += 1;
            }
        }
    }
    info!("[CMPR] finished, compressed from {:.3}% to {:.3}% (+{:.3}%)", init_sol.density() * 100.0, best_sol.density() * 100.0, (best_sol.density() - init_sol.density()) * 100.0);
    best_sol
}


fn attempt_to_compress<P: StripLike>(sep: &mut Separator<P>, init_sol: &P::Solution, r_shrink: f32, term: &impl Terminator, sol_listener: &mut impl SolutionListener<P::Solution>) -> Option<P::Solution> {
    // Restore to the initial solution and width
    sep.change_strip_width(init_sol.strip_width(), None).ok()?;
    sep.rollback(init_sol, None);

    // Shrink the container by the provided amount at a random position (chosen by the problem:
    // anywhere in the strip, or within the last sheet in multi-sheet mode)
    let new_width = init_sol.strip_width() * (1.0 - r_shrink);
    let split_pos = sep.prob.compress_split_position(&mut sep.rng);
    sep.change_strip_width(new_width, Some(split_pos)).ok()?;

    // Try to separate layout, if all collisions are eliminated, return the solution
    let (compacted_sol, ot) = sep.separate(term, sol_listener);
    match ot.get_total_loss() == 0.0 {
        true => Some(compacted_sol),
        false => None,
    }
}
