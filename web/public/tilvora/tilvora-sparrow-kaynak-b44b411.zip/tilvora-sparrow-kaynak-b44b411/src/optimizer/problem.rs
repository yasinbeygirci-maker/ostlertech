//! Abstraction over "strip-like" packing problems (Tilvora addition, MIT).
//!
//! Sparrow's search only needs a handful of operations from the problem it optimizes: a single
//! [`Layout`] to query, a scalar "strip width" that can be shrunk, and the ability to place, remove,
//! save and restore items. Both the original strip packing problem ([`SPProblem`]) and the
//! fixed-size multi-sheet problem ([`crate::sheet::SheetProblem`]) implement this trait, so the
//! exploration, compression and separation code is shared without modification of `jagua-rs`.

use jagua_rs::entities::{Item, Layout, LayoutSnapshot, PItemKey};
use jagua_rs::probs::spp::entities::{SPPlacement, SPProblem, SPSolution};
use rand::{Rng, RngExt};
use std::sync::Arc;

/// A packing problem with one layout whose feasible region is bounded on the right by a movable edge.
pub trait StripLike: Clone + Send + Sync {
    /// Immutable snapshot of the problem state.
    type Solution: StripSolution;

    /// The single layout in which all items are placed.
    fn layout(&self) -> &Layout;

    /// Current position of the movable right edge ("strip width").
    fn strip_width(&self) -> f32;

    /// Moves the right edge, keeping the left edge fixed. Items are not moved.
    fn change_strip_width(&mut self, new_width: f32) -> anyhow::Result<()>;

    /// Shrinks the width to the minimum that still contains all placed items.
    fn fit_strip(&mut self) -> anyhow::Result<()>;

    /// Places an item; panics if its demand is exhausted.
    fn place_item(&mut self, placement: SPPlacement) -> PItemKey;

    /// Removes a placed item and returns its placement.
    fn remove_item(&mut self, pk: PItemKey) -> SPPlacement;

    fn save(&self) -> Self::Solution;

    fn restore(&mut self, solution: &Self::Solution);

    /// Ratio of placed item area to container area (as reported in logs).
    fn density(&self) -> f32;

    /// The items of the instance with their demanded quantities, indexed by `item.idx()`.
    fn items(&self) -> &[(Arc<Item>, usize)];

    /// Remaining (not yet placed) quantity per item index.
    fn item_demand_qtys(&self) -> &[usize];

    fn item(&self, idx: usize) -> &Arc<Item> {
        &self.items()[idx].0
    }

    fn total_item_qty(&self) -> usize {
        self.items().iter().map(|(_, qty)| *qty).sum()
    }

    fn n_placed_items(&self) -> usize {
        self.layout().placed_items().len()
    }

    /// Width the exploration phase shrinks to from `current_width` (default: `shrink_step` relative).
    fn next_explore_width(&self, current_width: f32, shrink_step: f32) -> f32 {
        current_width * (1.0 - shrink_step)
    }

    /// Items whose centroid lies right of this x move together with the right edge when the
    /// exploration phase changes the strip width (default: the strip center, as in Sparrow).
    fn explore_split_position(&self) -> f32 {
        self.strip_width() / 2.0
    }

    /// Split position for one compression attempt (default: uniform over the whole strip).
    fn compress_split_position(&self, rng: &mut impl Rng) -> f32 {
        rng.random_range(0.0..self.strip_width())
    }
}

/// Snapshot of a [`StripLike`] problem.
pub trait StripSolution: Clone + Send + Sync {
    fn strip_width(&self) -> f32;
    fn density(&self) -> f32;
    fn layout_snapshot(&self) -> &LayoutSnapshot;
}

impl StripLike for SPProblem {
    type Solution = SPSolution;

    fn layout(&self) -> &Layout {
        SPProblem::layout(self)
    }

    fn strip_width(&self) -> f32 {
        SPProblem::strip_width(self)
    }

    fn change_strip_width(&mut self, new_width: f32) -> anyhow::Result<()> {
        SPProblem::change_strip_width(self, new_width)
    }

    fn fit_strip(&mut self) -> anyhow::Result<()> {
        SPProblem::fit_strip(self)
    }

    fn place_item(&mut self, placement: SPPlacement) -> PItemKey {
        SPProblem::place_item(self, placement)
    }

    fn remove_item(&mut self, pk: PItemKey) -> SPPlacement {
        SPProblem::remove_item(self, pk)
    }

    fn save(&self) -> SPSolution {
        SPProblem::save(self)
    }

    fn restore(&mut self, solution: &SPSolution) {
        SPProblem::restore(self, solution)
    }

    fn density(&self) -> f32 {
        SPProblem::density(self)
    }

    fn items(&self) -> &[(Arc<Item>, usize)] {
        &self.instance().items
    }

    fn item_demand_qtys(&self) -> &[usize] {
        SPProblem::item_demand_qtys(self)
    }
}

impl StripSolution for SPSolution {
    fn strip_width(&self) -> f32 {
        SPSolution::strip_width(self)
    }

    fn density(&self) -> f32 {
        SPSolution::density(self)
    }

    fn layout_snapshot(&self) -> &LayoutSnapshot {
        SPSolution::layout_snapshot(self)
    }
}
