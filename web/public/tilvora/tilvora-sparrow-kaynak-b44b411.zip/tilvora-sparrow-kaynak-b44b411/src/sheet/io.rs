//! JSON import/export for the multi-sheet problem (Tilvora addition, MIT). See ARAYUZ.md.

use crate::optimizer::problem::StripSolution;
use crate::sheet::{SheetProblem, SheetSolution, SheetSpec};
use anyhow::{Result, ensure};
use itertools::Itertools;
use jagua_rs::Instant;
use jagua_rs::geometry::geo_traits::Transformable;
use jagua_rs::io::export::int_to_ext_transformation;
use jagua_rs::io::ext_repr::ExtPlacedItem;
use jagua_rs::io::import::Importer;
use jagua_rs::probs::spp::io::ext_repr::ExtItem;
use rayon::prelude::*;
use serde::{Deserialize, Serialize};

/// Sheet description in the input file.
#[derive(Serialize, Deserialize, Clone, Debug, PartialEq)]
pub struct ExtSheet {
    /// Sheet width along the strip direction; `null` = one unbounded sheet (plain strip packing).
    pub width: Option<f32>,
    /// Sheet height.
    pub height: f32,
    /// Edge margin inside each sheet (default 0).
    #[serde(default)]
    pub margin: f32,
    /// Dead space between sheets (default 0; raised automatically, see ARAYUZ.md).
    #[serde(default)]
    pub gap: f32,
    /// Number of sheets available (`null` = unlimited).
    #[serde(default)]
    pub count: Option<usize>,
}

impl From<ExtSheet> for SheetSpec {
    fn from(e: ExtSheet) -> Self {
        SheetSpec {
            width: e.width,
            height: e.height,
            margin: e.margin,
            gap: e.gap,
            max_count: e.count,
        }
    }
}

impl From<SheetSpec> for ExtSheet {
    fn from(s: SheetSpec) -> Self {
        ExtSheet {
            width: s.width,
            height: s.height,
            margin: s.margin,
            gap: s.gap,
            count: s.max_count,
        }
    }
}

/// Multi-sheet instance: the strip packing item format plus a `sheet` object.
#[derive(Serialize, Deserialize, Clone)]
pub struct ExtSheetInstance {
    pub name: String,
    /// Minimum distance between items (kerf). Omitted means zero.
    #[serde(default)]
    pub min_item_separation: f32,
    pub items: Vec<ExtItem>,
    pub sheet: ExtSheet,
}

/// One sheet of the solution.
#[derive(Serialize, Deserialize, Clone)]
pub struct ExtSheetLayout {
    /// Zero-based sheet index.
    pub index: usize,
    /// Item area / gross sheet area (for an unbounded sheet: / used_width * height).
    pub density: f32,
    /// Rightmost extent of the original item shapes on this sheet, in sheet-local coordinates.
    pub used_width: f32,
    /// Placements in sheet-local coordinates (x measured from the sheet's left edge).
    pub placed_items: Vec<ExtPlacedItem>,
}

/// Unused rectangle at the right of the last sheet.
#[derive(Serialize, Deserialize, Clone)]
pub struct ExtRemainder {
    pub sheet: usize,
    pub x_min: f32,
    pub x_max: f32,
    pub y_min: f32,
    pub y_max: f32,
    pub area: f32,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct ExtSheetSolution {
    pub sheet_count: usize,
    /// Sheet description actually used (the gap may have been raised).
    pub sheet: ExtSheet,
    /// Total item area / (sheet_count * gross sheet area). For an unbounded sheet: / (used width * height).
    pub density: f32,
    /// Total item area / (sheet_count * usable sheet area).
    pub usable_density: f32,
    /// Rightmost extent of the items on the last sheet, in sheet-local coordinates.
    pub last_sheet_used_width: f32,
    /// Unused rectangle of the last sheet (`null` for an unbounded sheet).
    pub remainder: Option<ExtRemainder>,
    /// `true` when more sheets were used than `sheet.count` allows.
    pub sheet_limit_exceeded: bool,
    /// Internal strip width (for diagnostics; sheet coordinates).
    pub strip_width: f32,
    pub run_time_sec: u64,
    pub sheets: Vec<ExtSheetLayout>,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct ExtSheetOutput {
    #[serde(flatten)]
    pub instance: ExtSheetInstance,
    pub solution: ExtSheetSolution,
}

/// Imports a multi-sheet instance. The items are inflated by half the separation like in the strip
/// packing import; the container/bars are handled by [`SheetProblem`].
pub fn import_instance(importer: &Importer, ext: &ExtSheetInstance) -> Result<SheetProblem> {
    let importer = importer.with_min_item_separation(ext.min_item_separation)?;
    ensure!(
        ext.items.iter().map(|item| item.base.id).all_unique(),
        "item IDs must be unique"
    );
    let items = ext
        .items
        .iter()
        .filter(|item| item.demand > 0)
        .collect_vec()
        .into_par_iter()
        .enumerate()
        .map(|(idx, item)| {
            Ok((
                importer.import_item(&item.base, idx)?,
                usize::try_from(item.demand)?,
            ))
        })
        .collect::<Result<Vec<_>>>()?;
    ensure!(!items.is_empty(), "instance must have positive item demand");

    let spec: SheetSpec = ext.sheet.clone().into();
    SheetProblem::new(items, spec, ext.min_item_separation, importer.cde_config)
}

/// Exports a solution: every item is assigned to a sheet and expressed in sheet-local coordinates.
#[must_use]
pub fn export(solution: &SheetSolution, epoch: Instant) -> ExtSheetSolution {
    let spec = *solution.spec();
    let geom = solution.geometry();
    let snapshot = solution.layout_snapshot();
    let pitch = spec.pitch().unwrap_or(0.0);

    // Sheet membership from the collision shape, which lies entirely inside one usable region.
    // The strip width may reach into a sheet that holds nothing (the search shrinks the width in
    // steps): only sheets up to the last one actually used count.
    let sheet_of = |pi: &jagua_rs::entities::PlacedItem| {
        let cd_bbox = pi.shape().bbox();
        spec.sheet_index_of(0.5 * (cd_bbox.x_min + cd_bbox.x_max)).min(geom.n_sheets.saturating_sub(1))
    };
    let n_sheets = snapshot
        .placed_items()
        .values()
        .map(|pi| sheet_of(pi) + 1)
        .max()
        .unwrap_or(1);

    let mut sheets: Vec<ExtSheetLayout> = (0..n_sheets)
        .map(|index| ExtSheetLayout {
            index,
            density: 0.0,
            used_width: 0.0,
            placed_items: vec![],
        })
        .collect();
    let mut sheet_item_area = vec![0.0f32; n_sheets];

    for pi in snapshot.placed_items().values() {
        let item = pi.item();
        let index = sheet_of(pi);
        let x_shift = index as f32 * pitch;

        let ext_dt = int_to_ext_transformation(&pi.d_transf(), &item.shape_orig().pre_transform);
        let orig_bbox = item
            .shape_orig()
            .shape
            .transform_clone(&ext_dt.compose())
            .bbox();
        let (tx, ty) = ext_dt.translation();
        let local_dt = jagua_rs::geometry::DTransformation::new(ext_dt.rotation(), (tx - x_shift, ty))
            .with_reflection(ext_dt.reflected);

        let sheet = &mut sheets[index];
        sheet.used_width = sheet.used_width.max(orig_bbox.x_max - x_shift);
        sheet.placed_items.push(ExtPlacedItem {
            item_id: item.external_id(),
            transformation: local_dt.into(),
        });
        sheet_item_area[index] += item.area();
    }

    let gross_area = |used_width: f32| match spec.width {
        Some(w) => w * spec.height,
        None => used_width.max(f32::EPSILON) * spec.height,
    };
    for (sheet, area) in sheets.iter_mut().zip(&sheet_item_area) {
        sheet.density = area / gross_area(sheet.used_width);
    }

    let total_item_area: f32 = sheet_item_area.iter().sum();
    let last_used = sheets.last().map_or(0.0, |s| s.used_width);
    let density = match spec.width {
        Some(w) => total_item_area / (n_sheets as f32 * w * spec.height),
        None => total_item_area / gross_area(last_used),
    };
    let usable_density = match spec.usable_width() {
        Some(uw) => total_item_area / (n_sheets as f32 * uw * spec.usable_height()),
        None => total_item_area / ((last_used - spec.margin).max(f32::EPSILON) * spec.usable_height()),
    };
    let remainder = spec.width.map(|w| {
        let x_min = last_used.max(spec.margin);
        let x_max = w - spec.margin;
        ExtRemainder {
            sheet: n_sheets - 1,
            x_min,
            x_max,
            y_min: spec.margin,
            y_max: spec.height - spec.margin,
            area: (x_max - x_min).max(0.0) * spec.usable_height(),
        }
    });

    ExtSheetSolution {
        sheet_count: n_sheets,
        sheet: spec.into(),
        density,
        usable_density,
        last_sheet_used_width: last_used,
        remainder,
        sheet_limit_exceeded: spec.max_count.is_some_and(|n| n_sheets > n),
        strip_width: solution.strip_width(),
        run_time_sec: solution.time_stamp.duration_since(epoch).as_secs(),
        sheets,
    }
}
