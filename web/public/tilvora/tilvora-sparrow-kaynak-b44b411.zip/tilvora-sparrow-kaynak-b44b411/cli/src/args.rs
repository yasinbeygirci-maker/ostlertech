use clap::Parser;
use log::warn;
use sparrow::config::SparrowConfig;
use std::num::NonZeroUsize;

#[derive(Parser)]
pub struct MainCli {
    /// Path to input file (mandatory)
    #[arg(short = 'i', long, help = "Path to the input JSON file, or a solution JSON file for warm starting")]
    pub input: String,

    /// Global time limit in seconds (mutually exclusive with -e and -c)
    #[arg(short = 't', long, conflicts_with_all = &["exploration", "compression"], help = "Set a global time limit (in seconds)")]
    pub global_time: Option<u64>,

    /// Exploration time limit in seconds (requires compression time)
    #[arg(short = 'e', long, requires = "compression", help = "Set the exploration phase time limit (in seconds)")]
    pub exploration: Option<u64>,

    /// Compression time limit in seconds (requires exploration time)
    #[arg(short = 'c', long, requires = "exploration", help = "Set the compression phase time limit (in seconds)")]
    pub compression: Option<u64>,

    /// Enable early and automatic termination
    #[arg(short = 'x', long, help = "Enable early termination of the optimization process")]
    pub early_termination: bool,

    #[arg(short = 's', long, help = "Fixed seed for the random number generator")]
    pub rng_seed: Option<u64>,

    /// Number of worker threads used by the separator
    #[arg(long)]
    pub workers: Option<NonZeroUsize>,

    /// Directory for log, SVG and JSON output (default: `output` in the working directory)
    #[arg(short = 'o', long, help = "Output directory for log.txt, final_<name>.json and SVG files")]
    pub output_dir: Option<String>,

    /// Multi-sheet mode: initial solution builder
    #[arg(long, value_name = "KIND", default_value = "greedy", help = "Multi-sheet mode: initial solution builder (greedy | lbf)")]
    pub init: String,

    /// Multi-sheet mode: which items follow the moving right edge when the strip width changes
    #[arg(long, value_name = "MODE", default_value = "tail-center", help = "Multi-sheet mode: split position (tail-center | tail-start | end | center)")]
    pub sheet_split: String,

    /// Multi-sheet mode: exploration shrink step as a fraction of the sheet pitch
    #[arg(long, value_name = "RATIO", help = "Multi-sheet mode: exploration shrink step as a fraction of the sheet pitch (default: Sparrow's relative step)")]
    pub sheet_step: Option<f32>,

    /// Multi-sheet mode: compression phase variant
    #[arg(long, value_name = "KIND", default_value = "explore", help = "Multi-sheet mode: second phase (explore = exploration takes the whole budget | tail = try to drop the last sheet | strip = Sparrow's relative shrink)")]
    pub sheet_compress: String,

    /// Multi-sheet mode: uniform samples per sheet attempt of the greedy builder
    #[arg(long, value_name = "N", help = "Multi-sheet mode: samples per sheet attempt in the greedy builder (default 100)")]
    pub greedy_samples: Option<usize>,
}

impl MainCli {
    /// Applies optional CLI values that override the default optimizer configuration.
    pub fn apply_config_overrides(&self, config: &mut SparrowConfig) {
        if let Some(rng_seed) = self.rng_seed {
            warn!("[MAIN] overriding RNG seed: {rng_seed}");
            config.rng_seed = Some(rng_seed as usize);
        }
        if let Some(workers) = self.workers {
            warn!("[MAIN] overriding separator worker count: {workers}");
            config.expl_cfg.separator_config.n_workers = workers.get();
            config.cmpr_cfg.separator_config.n_workers = workers.get();
        }
    }
}
