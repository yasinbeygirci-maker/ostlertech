use crate::quantify::tracker::CollisionTracker;
use crate::quantify::{hole_bbox, quantify_collision_poly_bar, quantify_collision_poly_container, quantify_collision_poly_poly};
use float_cmp::{approx_eq, assert_approx_eq};
use itertools::Itertools;
use jagua_rs::collision_detection::hazards::collector::{BasicHazardCollector, HazardCollector};
use jagua_rs::collision_detection::hazards::BasicHazardEntity;
use jagua_rs::collision_detection::hazards::filter::NoFilter;
use jagua_rs::entities::Layout;
use jagua_rs::io::svg::SvgDrawOptions;
use jagua_rs::util::assertions;
use log::warn;

pub fn tracker_matches_layout(ct: &CollisionTracker, l: &Layout) -> bool {
    assert!(l.placed_items().keys().all(|k| ct.pk_idx_map.contains_key(k)));
    assert!(assertions::layout_cde_matches_fresh(l));

    for (pk1, pi1) in l.placed_items().iter() {
        let mut collector = BasicHazardCollector::new();
        l.cde().collect_poly_collisions(pi1.shape(), &NoFilter, &mut collector);
        collector.remove_by_entity(&BasicHazardEntity::from((pk1, pi1)));
        assert_eq!(ct.get_pair_loss(pk1, pk1), 0.0);
        for (pk2, pi2) in l.placed_items().iter().filter(|(k, _)| *k != pk1) {
            let stored_loss = ct.get_pair_loss(pk1, pk2);
            match collector.iter().any(|(_, he)| he == &BasicHazardEntity::from((pk2, pi2))) {
                true => {
                    let calc_loss = quantify_collision_poly_poly(pi1.shape(), pi2.shape());
                    let calc_loss_r = quantify_collision_poly_poly(pi2.shape(), pi1.shape());
                    if !approx_eq!(f32,calc_loss,stored_loss,epsilon = 0.10 * stored_loss) && !approx_eq!(f32,calc_loss_r,stored_loss, epsilon = 0.10 * stored_loss) {
                        let mut opp_collector = BasicHazardCollector::new();
                        l.cde().collect_poly_collisions(pi2.shape(), &NoFilter, &mut opp_collector);
                        opp_collector.remove_by_entity(&BasicHazardEntity::from((pk2, pi2)));
                        if opp_collector.contains_entity(&((pk1, pi1).into())) {
                            dbg!(&pi1.shape().vertices(), &pi2.shape().vertices());
                            dbg!(
                                stored_loss,
                                calc_loss,
                                calc_loss_r,
                                opp_collector.iter().collect_vec(),
                                BasicHazardEntity::from((pk1, pi1)),
                                BasicHazardEntity::from((pk2, pi2))
                            );
                            panic!("tracker error");
                        }  else if stored_loss == 0.0 {
                            //detecting collisions is not symmetrical (in edge cases)
                            warn!("non-symmetrical collision!");
                            // dbg!(stored_loss, calc_loss, calc_loss_r);
                            // warn!(
                            //         "collisions: pi_1 {:?} -> {:?}",
                            //         BasicHazardEntity::from((pk1, pi1)),
                            //         collector.iter().collect_vec()
                            //     );
                            // warn!(
                            //         "opposite collisions: pi_2 {:?} -> {:?}",
                            //         BasicHazardEntity::from((pk2, pi2)),
                            //         opp_collector.iter().collect_vec()
                            //     );
                            //
                            // warn!(
                            //         "pi_1: {:?}",
                            //         pi1.shape
                            //             .vertices
                            //             .iter()
                            //             .map(|p| format!("({},{})", p.0, p.1))
                            //             .collect_vec()
                            //     );
                            // warn!(
                            //         "pi_2: {:?}",
                            //         pi2.shape
                            //             .vertices
                            //             .iter()
                            //             .map(|p| format!("({},{})", p.0, p.1))
                            //             .collect_vec()
                            //     );
                        }
                        else {
                            dbg!(&pi1.shape().vertices(), &pi2.shape().vertices());
                            dbg!(
                                    stored_loss,
                                    calc_loss,
                                    calc_loss_r,
                                    opp_collector.iter().collect_vec(),
                                    BasicHazardEntity::from((pk1, pi1)),
                                    BasicHazardEntity::from((pk2, pi2))
                                );
                            panic!("tracker error");
                        }
                    }
                }
                false => {
                    if stored_loss != 0.0 {
                        let calc_loss = quantify_collision_poly_poly(pi1.shape(), pi2.shape());
                        let mut opp_collector = BasicHazardCollector::new();
                        l.cde().collect_poly_collisions(pi2.shape(), &NoFilter, &mut opp_collector);
                        opp_collector.remove_by_entity(&BasicHazardEntity::from((pk2, pi2)));
                        if !opp_collector.contains_entity(&BasicHazardEntity::from((pk1, pi1))) {
                            dbg!(&pi1.shape().vertices(), &pi2.shape().vertices());
                            dbg!(
                                stored_loss,
                                calc_loss,
                                opp_collector.iter().collect_vec(),
                                BasicHazardEntity::from((pk1, pi1)),
                                BasicHazardEntity::from((pk2, pi2))
                            );
                            panic!("tracker error");
                        } else {
                            //detecting collisions is not symmetrical (in edge cases)
                            warn!("inconsistent loss");
                            warn!(
                                "collisions: {:?} -> {:?}",
                                BasicHazardEntity::from((pk1, pi1)),
                                collector.iter().collect_vec()
                            );
                            warn!(
                                "opposite collisions: {:?} -> {:?}",
                                BasicHazardEntity::from((pk2, pi2)),
                                opp_collector.iter().collect_vec()
                            );
                        }
                    }
                }
            }
        }
        // Container loss = exterior loss + loss against every static bar (hole) the item collides with.
        let calc_loss: f32 = collector.iter()
            .map(|(_, he)| match he {
                BasicHazardEntity::Exterior => quantify_collision_poly_container(pi1.shape(), l.container().outer_cd().bbox()),
                BasicHazardEntity::Hole { idx } => quantify_collision_poly_bar(pi1.shape(), hole_bbox(l, *idx)),
                _ => 0.0,
            })
            .sum();
        let stored_loss = ct.get_container_loss(pk1);
        if calc_loss > 0.0 {
            assert_approx_eq!(f32, stored_loss, calc_loss, epsilon = 1e-4 * calc_loss, ulps = 5);
        } else {
            assert_eq!(stored_loss, 0.0);
        }
    }

    true
}
